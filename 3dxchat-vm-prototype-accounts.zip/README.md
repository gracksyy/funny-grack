# Separate-VM prototype

This package runs the current Node server on an Ubuntu VM, while the Build473 game clients stay on Windows. It includes native email/password sign-in, administrator-created test accounts, saved characters/appearances, the test world, shared Local Room, movement, solo/paired animations, partner/pose cleanup and resumption, local/private/global chat, friendships, text profiles, chat mute/unmute and simple moderator kick. Ban opens a local informational page; it does not apply a ban.

The package contains a snapshot of the existing local test characters, profile text, friendships and world. Keep it private. It contains no game executable, GameAssembly.dll, captures, process dumps, production credentials or saved bearer tokens.

This is a trusted-network testing prototype with up to 16 accounts, three character slots per account and eight simultaneous gameplay connections. It is not an Internet-ready account service. Exact client source-IP allowlisting is enforced for HTTP and gameplay TCP. Loopback is always allowed for local health checks. Login verifies the credentials entered in the game; moderator rights come from the stored account role, not a login URL or client flag. Passwords use salted scrypt hashes; bearer tokens stay in memory. Use unique test-only passwords and keep both ports private/VPN-accessible: the native payload codec is compatibility encryption, not a substitute for transport security, and gameplay TCP is plain TCP.

## Ubuntu setup

Use Ubuntu 24.04 LTS or another release supported by [Docker's Ubuntu installation guide](https://docs.docker.com/engine/install/ubuntu/). Install Docker Engine and the Compose plugin using that guide. The image uses the [official Node image](https://hub.docker.com/_/node); there are no npm dependencies to install separately.

Extract this ZIP to a new folder, for example `~/3dxchat-vm`. Do not extract over an existing server's data folder. From that folder:

```bash
cp .env.example .env
nano .env
nano server-config.json
```

Set `.env` to the VM's **private IPv4 address**, for example:

```dotenv
VM_BIND_ADDRESS=192.168.1.50
```

Set `allowedClients` in `server-config.json` to the Windows client PC's source IPv4 address. For example:

```json
"allowedClients": ["192.168.1.20"]
```

The two addresses above are examples, not detected addresses. Add each actual client PC separately. With the default empty list and loopback binding, remote access is disabled. Do not replace the client allowlist with a Docker gateway address to bypass a denial. The server does not trust forwarded-IP headers.

Keep the container's HTTP port at 8080 and gameplay TCP at 8125 with this Compose file. Docker publishes HTTP on VM port 80 because a long address with an explicit port can exceed the original client's URL buffers. Keep `moderatorId` as an existing seeded character ID (default LocalTest); disable `moderationEnabled` if all clients should be ordinary.

Prepare the bind-mounted data folder for the container's non-root UID, then start:

```bash
sudo chown -R 1000:1000 ./data
sudo docker compose up -d --build
sudo docker compose ps
sudo docker compose logs --tail 30 game-server
```

Allow traffic from the client PCs to VM TCP 80 and 8125 in any hypervisor/cloud/network firewall. Docker-published ports can bypass UFW rules; use the private-interface binding and application allowlist, and Docker-supported filtering when required. See [Docker's firewall notes](https://docs.docker.com/engine/install/ubuntu/#firewall-limitations). No firewall rules or VM packages are changed by the Windows scripts.

The container uses a writable `data/` mount, a read-only application image, UID 1000, a 512 MB memory limit and rotated metadata-only logs. Back up the entire `data/` directory while stopped, including accounts.json and account-admin.key. To stop without deleting progress:

```bash
sudo docker compose down
```

When updating, preserve `data/` and your configuration. Session tokens and active rooms/mutes are in memory; a server restart requires fresh client login, while characters, friends and text profiles persist.

## Accounts and passwords

First startup imports the existing characters into two **disabled-until-initialized** accounts: moderator@example.com owns LocalTest; offline@example.com owns LocalPeer/LocalObserver. Set their passwords from the VM console to keep using the existing progress:

```bash
sudo docker compose exec game-server node inspection/vm/accounts.cjs set-password --email moderator@example.com
sudo docker compose exec game-server node inspection/vm/accounts.cjs set-password --email offline@example.com
```

Passwords are entered twice at masked prompts, not passed as command-line arguments. Use 8–128 characters with no spaces or control characters; the game's login UI removes ordinary spaces. Email matching is case-insensitive and passwords are case-sensitive. There are no built-in default passwords.

Create additional independent accounts:

```bash
sudo docker compose exec game-server node inspection/vm/accounts.cjs create --email tester1@example.test
sudo docker compose exec game-server node inspection/vm/accounts.cjs create --email tester2@example.test
sudo docker compose exec game-server node inspection/vm/accounts.cjs list
```

New accounts have no characters. Sign in normally in the game and create their characters there. Each account can own three; character names are globally unique. To explicitly create another moderator account, add `--role moderator` to create. Account creation, listing and password changes require a management key generated on the VM in data/account-admin.key; the CLI reads it locally and submits protected administrator requests. Ordinary game tokens cannot access that API. The key is never printed or copied from the original project into this package.

The same set-password command resets an account password and revokes its existing bearer tokens. Connected clients are denied on their next gameplay frame and must sign in again. Account creation is through this VM administrator CLI; public signup, email delivery/verification and the game's production forgot-password page are not implemented. The opaque native login request is decoded only for email/password; hardware IDs, device details and old client tokens are discarded and never persisted or logged.

## Windows client setup

The original project now has `inspection/startup/connect-vm.ps1`. The ZIP also contains a standalone `client/` copy of that script and its helpers. Use PowerShell 5.1 or later. The script validates the original GameAssembly build hash, URL lengths, VM health marker and TCP reachability before writing any client memory.

First check connectivity from the Windows PC, replacing the example address:

```powershell
.\inspection\startup\connect-vm.ps1 -ServerUrl 'http://192.168.1.50/' -CheckOnly
```

If using the ZIP's `client/` folder instead, add `-ProjectRoot 'C:\path\to\3DXChat'`; that folder must contain `Game/3DXChat.exe` and `Game/GameAssembly.dll`.

If a new Windows PowerShell session blocks scripts, review the client files, unblock downloaded `.ps1` files if needed, and use a process-scoped RemoteSigned session. For example, `powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File .\client\connect-vm.ps1 -ProjectRoot 'C:\path\to\3DXChat' -ServerUrl 'http://192.168.1.50/' -CheckOnly`. No machine-wide execution-policy change is required.

Open two game clients at login, without signing in, and connect both:

```powershell
$clients = @(Get-Process 3DXChat | Sort-Object Id)
if ($clients.Count -ne 2) { throw 'Expected two clients' }
.\inspection\startup\connect-vm.ps1 `
  -ServerUrl 'http://192.168.1.50/' `
  -ClientPid $clients[0].Id `
  -AdditionalClientPids $clients[1].Id `
  -ModeratorClientPid $clients[0].Id `
  -Seconds 180
```

After **both** endpoint verifications, enter each VM account's email and the password you configured, manually, with Remember Me unchecked. For the imported accounts, moderator@example.com exposes LocalTest and offline@example.com exposes LocalPeer/LocalObserver. For new accounts, create a character after sign-in. Enter My Place, then Travel to Local Room, check appearance/movement/chat, and close both before the three-minute window ends. The client launcher never starts or stops the VM server.

For a longer session, replace `-Seconds 180` with `-UntilClientExit`. Keep PowerShell open until every selected client is closed. It uses an eight-hour safety ceiling. All endpoint bytes are restored if a live client remains when the worker finishes; if the client exits, its temporary memory changes disappear. No game files are patched. Avoid ending PowerShell while clients are still using redirected endpoints.

ModeratorClientPid is optional with email/password login: both login routes verify credentials and the actual account determines its role. Different accounts see only their own characters. Multiple clients on one account must choose different characters. Gameplay port 8125 is currently fixed in the client; a different server TCP port is rejected. Root HTTP(S) URLs must fit the existing buffers. HTTPS requires a separately configured reverse proxy/certificate and has not been configured by this package.

## Troubleshooting and validation limits

* HTTP 403 / client address denied: confirm the client's source IP is in allowedClients and restart the server after configuration changes.
* HTTP unreachable: check VM_BIND_ADDRESS, Docker status, port 80 and network routing.
* TCP unreachable: check VM TCP 8125 independently; HTTP success is insufficient.
* URL does not fit: use port 80 without an explicit port or a short resolvable hostname. IPv4 addresses fit at port 80.
* Data permission error: ensure the package's data folder is writable by UID 1000. Keep the existing character/profile/friend JSON files intact.
* Server restarted: close/reopen the game and sign in again during a fresh redirection window.

The server runtime, native credential codec against independent .NET fixtures, account creation/authentication/ownership, protocol features, access restrictions, state reload, endpoint plans and client-worker forwarding are checked locally. Docker/Ubuntu execution and actual game-client credential acceptance/cross-VM gameplay still require testing on your VM. The prototype retains the eight-connection scale and per-character encrypted world cache. It does not include public production account infrastructure, arbitrary world uploads, profile galleries, reaction mutes or ban enforcement.
