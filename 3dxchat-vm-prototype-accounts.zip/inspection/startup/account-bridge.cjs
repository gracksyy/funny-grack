const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {decodeLoginRequest}=require('./login-request-codec.cjs');
function createAccountBridge({store,keyFile}={}){
 if(!store||!keyFile)throw Error('Account store and management key file required');
 let key;
 if(fs.existsSync(keyFile))key=fs.readFileSync(keyFile,'utf8').trim();
 else{fs.mkdirSync(path.dirname(keyFile),{recursive:true});key=crypto.randomBytes(32).toString('hex');fs.writeFileSync(keyFile,key+'\n',{flag:'wx',mode:0o600});}
 if(! /^[a-f0-9]{64}$/.test(key))throw Error('Invalid account management key');
 const attempts=new Map();let active=0;
 function manager(request){const value=request.headers['x-vm-admin-key'];return typeof value==='string'&&/^[a-f0-9]{64}$/.test(value)&&crypto.timingSafeEqual(Buffer.from(value,'hex'),Buffer.from(key,'hex'));}
 return {store,
  async login(form,address){
   const now=Date.now();for(const [ip,b] of attempts)if(now-b.start>=60000)attempts.delete(ip);
   if(!attempts.has(address)){if(attempts.size>=256)return {status:429};attempts.set(address,{start:now,count:0,failures:0});}
   const bucket=attempts.get(address);if(++bucket.count>30||bucket.failures>=10||active>=4)return {status:429};
   let credentials;try{credentials=decodeLoginRequest(form);}catch{bucket.failures++;return {status:200,profile:null};}
   active++;try{const profile=await store.authenticate(credentials.email,credentials.password);if(!profile)bucket.failures++;return {status:200,profile};}finally{active--;credentials.password='';}
  },
  management(request,send){
   const pathname=new URL(request.url,'http://127.0.0.1').pathname;
   if(!['/admin/accounts','/admin/accounts/password'].includes(pathname))return false;
   if(!manager(request)){request.resume();send(403,JSON.stringify({error:'forbidden'}),'application/json');return true;}
   if(request.method==='GET'&&pathname==='/admin/accounts'){request.resume();send(200,JSON.stringify({accounts:store.list()}),'application/json');return true;}
   if(request.method!=='POST'||request.headers['content-type']?.split(';')[0]!=='application/json'){request.resume();send(405,JSON.stringify({error:'invalid-request'}),'application/json');return true;}
   let size=0,rejected=false;const chunks=[];
   request.on('data',chunk=>{size+=chunk.length;if(size>8192&&!rejected){rejected=true;send(413,JSON.stringify({error:'too-large'}),'application/json');}if(!rejected)chunks.push(chunk);});
   request.on('end',async()=>{
    if(rejected)return;
    try{
     const value=JSON.parse(Buffer.concat(chunks).toString('utf8'));
     const allowed=pathname==='/admin/accounts'?['email','password','role']:['email','password'];
     if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!allowed.includes(k)))throw Error('Invalid request');
     const account=pathname==='/admin/accounts'?await store.create(value.email,value.password,value.role||'user'):await store.setPassword(value.email,value.password);
     value.password='';send(200,JSON.stringify({account}),'application/json');
    }catch{send(400,JSON.stringify({error:'invalid-account-or-password'}),'application/json');}
   });return true;
  }
 };
}
module.exports={createAccountBridge};
