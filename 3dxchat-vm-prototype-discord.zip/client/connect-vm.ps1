param(
 [Parameter(Mandatory=$true)][string]$ServerUrl,
 [int]$ClientPid=0,
 [int[]]$AdditionalClientPids=@(),
 [int]$ModeratorClientPid=0,
 [string]$ProjectRoot='',
 [string]$GameplayHost='',
 [ValidateRange(10,180)][int]$Seconds=180,
 [switch]$UntilClientExit,
 [switch]$CheckOnly
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'client-endpoint-plan.ps1')
. (Join-Path $PSScriptRoot 'invoke-local-redirections.ps1')
$taskPlan=Get-ClientEndpointPlan -ServerBaseUrl $ServerUrl -GameplayHost $GameplayHost -LocalModerationWeb
if(!$ProjectRoot){$ProjectRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))}
$taskRoot=[IO.Path]::GetFullPath($ProjectRoot)
$taskGame=Join-Path $taskRoot 'Game/3DXChat.exe'
$taskDll=Join-Path $taskRoot 'Game/GameAssembly.dll'
if(!(Test-Path -LiteralPath $taskDll -PathType Leaf) -or !(Test-Path -LiteralPath $taskGame -PathType Leaf)){throw 'ProjectRoot must contain Game/3DXChat.exe and Game/GameAssembly.dll'}
$taskHashAlgorithm=[Security.Cryptography.SHA256]::Create();$taskDllStream=[IO.File]::OpenRead($taskDll)
try{$taskHash=([BitConverter]::ToString($taskHashAlgorithm.ComputeHash($taskDllStream))).Replace('-','')}finally{$taskDllStream.Dispose();$taskHashAlgorithm.Dispose()}
if($taskHash -cne 'BFA9E62532E9DAF2E264D36CD4916A6C4BC49BF483945F52753D678CDD457EBC'){throw 'GameAssembly.dll differs from validated Build473; no writes performed'}
$taskHealth=(Invoke-WebRequest -Uri ($taskPlan.BaseUrl+'health') -UseBasicParsing -TimeoutSec 5).Content|ConvertFrom-Json
if($taskHealth.deploymentMode -cne 'vm-prototype' -or $taskHealth.serverId -cne '3dxchat-vm-v1' -or $taskHealth.editorHandshake -ne $true -or $taskHealth.worldDownloads -ne $true -or $taskHealth.tcpPort -ne 8125){throw 'Expected VM prototype with gameplay TCP 8125 is not ready'}
if($ModeratorClientPid -and $taskHealth.moderationEnabled -ne $true){throw 'Moderator role is disabled on this VM server'}
$taskProbe=[Net.Sockets.TcpClient]::new()
try{$taskConnect=$taskProbe.BeginConnect($taskPlan.GameplayHost,8125,$null,$null);if(!$taskConnect.AsyncWaitHandle.WaitOne(3000)){throw 'VM gameplay TCP port 8125 is unreachable'};$taskProbe.EndConnect($taskConnect)}finally{$taskProbe.Dispose()}
if($CheckOnly){Write-Output 'PASS: validated client build, fitting URLs, VM HTTP health and gameplay TCP reachable; no client memory changed';return}
if(!$ClientPid){$taskCandidates=@(Get-Process -Name 3DXChat -ErrorAction SilentlyContinue|Where-Object {$_.Path -ieq $taskGame});if($taskCandidates.Count -ne 1){throw 'Open one client at login, or supply ClientPid and AdditionalClientPids'};$ClientPid=$taskCandidates[0].Id}
$taskClientIds=@($ClientPid)+@($AdditionalClientPids)
if($taskClientIds.Count -gt 3 -or @($taskClientIds|Select-Object -Unique).Count -ne $taskClientIds.Count){throw 'Supply one to three distinct client IDs'}
if($ModeratorClientPid -and $ModeratorClientPid -notin $taskClientIds){throw 'ModeratorClientPid must identify a selected client'}
$taskPatch=Join-Path $PSScriptRoot 'redirect-save-test.ps1'
foreach($taskTarget in $taskClientIds){
 $taskProcess=Get-Process -Id $taskTarget
 if($taskProcess.Path -ine $taskGame){throw 'Selected process does not belong to ProjectRoot'}
 & $taskPatch -ClientPid $taskTarget -Seconds $Seconds -ServerBaseUrl $taskPlan.BaseUrl -GameplayHost $taskPlan.GameplayHost -LocalModerationWeb -ModeratorLogin:($taskTarget -eq $ModeratorClientPid)
}
$taskLogDir=Join-Path $taskRoot 'inspection/startup/vm-client-runs'
[void][IO.Directory]::CreateDirectory($taskLogDir)
$taskPrefix=Join-Path $taskLogDir ((Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8))
Write-Output 'VM reachable. Keep clients at login until all endpoint verifications complete.'
if($taskHealth.passwordLogin -eq $true){Write-Output 'Then enter each VM test account email/password manually with Remember Me unchecked. Role comes from the authenticated account.'}else{Write-Output 'Then enter offline@example.com / offline-test manually with Remember Me unchecked.'}
if($UntilClientExit){Write-Output 'Keep this PowerShell open until every selected client exits. Endpoint redirection has an eight-hour safety limit.'}
else{Write-Output "Close every selected client before the $Seconds-second window ends."}
Invoke-LocalClientRedirections -PatchPath $taskPatch -ClientPids $taskClientIds -Seconds $Seconds -LogPrefix $taskPrefix -ModeratorClientPid $ModeratorClientPid -LocalModerationWeb -ServerBaseUrl $taskPlan.BaseUrl -GameplayHost $taskPlan.GameplayHost -RequireVmServer -UntilClientExit:$UntilClientExit
Write-Output 'VM client session finished; the VM service remains running.'
