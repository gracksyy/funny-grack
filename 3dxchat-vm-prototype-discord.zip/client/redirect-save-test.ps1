param([int]$ClientPid=42188,[int]$Seconds=180,[switch]$Apply,[string]$LifecycleLog='',[switch]$ModeratorLogin,[switch]$LocalModerationWeb,[string]$ServerBaseUrl='http://127.0.0.1:18744/',[string]$GameplayHost='',[switch]$RequireVmServer,[switch]$UntilClientExit)
$ErrorActionPreference='Stop'
if($Seconds -lt 10 -or $Seconds -gt 300){throw 'Test duration must be 10 to 300 seconds'}
. (Join-Path $PSScriptRoot 'client-endpoint-plan.ps1')
$taskPlan=Get-ClientEndpointPlan -ServerBaseUrl $ServerBaseUrl -GameplayHost $GameplayHost -ModeratorLogin:$ModeratorLogin -LocalModerationWeb:$LocalModerationWeb
if(-not ('LoginEndpointTestMemory' -as [type])){
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class LoginEndpointTestMemory {
 [DllImport("kernel32.dll",SetLastError=true)] public static extern IntPtr OpenProcess(uint rights,bool inherit,int pid);
 [DllImport("kernel32.dll",SetLastError=true)] public static extern bool ReadProcessMemory(IntPtr handle,IntPtr address,byte[] bytes,UIntPtr count,out UIntPtr read);
 [DllImport("kernel32.dll",SetLastError=true)] public static extern bool WriteProcessMemory(IntPtr handle,IntPtr address,byte[] bytes,UIntPtr count,out UIntPtr written);
 [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr handle);
}
'@
}
$process=Get-Process -Id $ClientPid
$module=$process.Modules | Where-Object ModuleName -eq 'GameAssembly.dll'
if(!$module){throw 'GameAssembly.dll is not loaded'}
$base=$module.BaseAddress.ToInt64()
$rights=if($Apply){0x438}else{0x410}
$handle=[LoginEndpointTestMemory]::OpenProcess($rights,$false,$ClientPid)
if($handle -eq [IntPtr]::Zero){throw 'Could not open client process'}
function ReadBytes([long]$address,[int]$count){
 $bytes=[byte[]]::new($count);$read=[UIntPtr]::Zero
 $taskReadOk=[LoginEndpointTestMemory]::ReadProcessMemory($handle,[IntPtr]$address,$bytes,[UIntPtr]::new([uint64]$count),[ref]$read)
 $taskReadError=[Runtime.InteropServices.Marshal]::GetLastWin32Error()
 if(!$taskReadOk -or $read.ToUInt64()-ne $count){throw ('Memory read failed: stage={0}; address=0x{1:x}; requested={2}; read={3}; Win32={4}; PowerShell={5}; pointerBits={6}' -f $memoryReadStage,$address,$count,$read.ToUInt64(),$taskReadError,$PSVersionTable.PSVersion,([IntPtr]::Size*8))}
 return ,$bytes
}
function Pointer([long]$address){return [BitConverter]::ToInt64((ReadBytes $address 8),0)}
function EndpointClass([long]$slot,[string]$name){
 $memoryReadStage=$name+' class slot';$taskClass=Pointer $slot
 # The native resolver tests bit 0 before dereferencing a metadata-usage slot.
 # For usage kind 1 it reads the class cache at 0x6761b08 using bits 1..28.
 if(($taskClass -band 1) -ne 0){
  if($taskClass -gt [uint32]::MaxValue -or ($taskClass -shr 29) -ne 1){throw ($name+' endpoint slot contains an unexpected tagged reference; no endpoint writes performed')}
  $taskTypeIndex=($taskClass -band 0x1fffffff) -shr 1
  $memoryReadStage=$name+' class cache';$taskCache=Pointer ($base+0x6761b08)
  if(!$taskCache){throw ($name+' endpoint class cache is unavailable; no endpoint writes performed')}
  $taskClass=Pointer ($taskCache+$taskTypeIndex*8)
  if(!$taskClass){throw ($name+' endpoint has not initialized during offline startup (class cache empty); no endpoint writes performed')}
 }
 if($taskClass -lt 0x10000 -or ($taskClass -band 7) -ne 0){throw ($name+' endpoint class is not a valid resolved pointer; no endpoint writes performed')}
 return $taskClass
}
function WriteBytes([long]$address,[byte[]]$bytes){
 $written=[UIntPtr]::Zero
 if(![LoginEndpointTestMemory]::WriteProcessMemory($handle,[IntPtr]$address,$bytes,[UIntPtr]::new([uint64]$bytes.Length),[ref]$written)-or $written.ToUInt64()-ne $bytes.Length){throw 'Endpoint write failed'}
}
$snapshots=@();$started=$false
try{
 $taskEndpointSpecs=$taskPlan.Specs
 foreach($spec in $taskEndpointSpecs){
  $class=EndpointClass ($base+$spec.rva) $spec.name
  $memoryReadStage=$spec.name+' static fields';$statics=Pointer ($class+0xb8)
  if(!$statics){throw ($spec.name+' endpoint static fields have not initialized; no endpoint writes performed')}
  $memoryReadStage=$spec.name+' string pointer';$string=Pointer ($statics+$spec.offset)
  if(!$string){throw 'Endpoint string absent'}
  $memoryReadStage=$spec.name+' string length';$length=[BitConverter]::ToInt32((ReadBytes ($string+0x10) 4),0)
  if($length -ne $spec.expected.Length){throw 'Endpoint length does not match validated build'}
  $memoryReadStage=$spec.name+' string contents';$old=ReadBytes ($string+0x10) (4+($length+1)*2)
  $text=[Text.Encoding]::Unicode.GetString($old,4,$length*2)
  if($text -cne $spec.expected){throw 'Endpoint value does not match validated build'}
  if($spec.replacement.Length -gt $length){throw 'Replacement cannot fit existing string allocation'}
  $new=[byte[]]::new($old.Length)
  [BitConverter]::GetBytes([int]$spec.replacement.Length).CopyTo($new,0)
  [Text.Encoding]::Unicode.GetBytes($spec.replacement).CopyTo($new,4)
  $snapshots+=@{address=$string+0x10;old=$old;new=$new;original=$text;replacement=$spec.replacement}
 }
 if(!$Apply){
  [pscustomobject]@{readOnlyPreflight=$true;pid=$ClientPid;testSeconds=$Seconds;endpoints=@($snapshots | ForEach-Object { @{from=$_.original;to=$_.replacement} });sharedRestBase=$true;writesPerformed=$false} | ConvertTo-Json -Depth 5
  return
 }
 # Refuse to redirect until the selected fixture service is ready.
 $health=Invoke-WebRequest -Uri ($taskPlan.BaseUrl+'health') -UseBasicParsing -TimeoutSec 5
 $healthInfo=$health.Content | ConvertFrom-Json
 if($healthInfo.mode -cne 'login-bootstrap' -or $healthInfo.editorHandshake -ne $true){throw 'Expected combined editor handshake fixture is not ready'}
 if($RequireVmServer -and ($healthInfo.deploymentMode -cne 'vm-prototype' -or $healthInfo.serverId -cne '3dxchat-vm-v1' -or $healthInfo.tcpPort -ne 8125)){throw 'Expected VM prototype on gameplay TCP port 8125 is not ready'}
 $log=if($LifecycleLog){$LifecycleLog}else{Join-Path $PSScriptRoot 'local-save-redirection.jsonl'}
 $started=$true
 foreach($snapshot in $snapshots){WriteBytes $snapshot.address $snapshot.new}
 foreach($snapshot in $snapshots){if([Convert]::ToBase64String((ReadBytes $snapshot.address $snapshot.new.Length))-cne [Convert]::ToBase64String($snapshot.new)){throw 'Endpoint readback mismatch'}}
 @{at=(Get-Date).ToString('o');event='applied';pid=$ClientPid;seconds=$Seconds;untilClientExit=[bool]$UntilClientExit} | ConvertTo-Json -Compress | Add-Content -LiteralPath $log
 Write-Output "Local login, REST and gameplay host verified active for selected server $($taskPlan.BaseUrl)."
 if($healthInfo.passwordLogin -eq $true){Write-Output 'Enter your VM test-account email/password manually; Remember Me unchecked.'}else{Write-Output 'Enter dummy credentials manually; Remember Me unchecked.'}
 $deadline=if($UntilClientExit){[DateTime]::UtcNow.AddHours(8)}else{[DateTime]::UtcNow.AddSeconds($Seconds)}
 while([DateTime]::UtcNow -lt $deadline){Start-Sleep -Milliseconds 500;if($process.HasExited){break}}
}finally{
 if($started -and !$process.HasExited){
  foreach($snapshot in $snapshots){WriteBytes $snapshot.address $snapshot.old}
  foreach($snapshot in $snapshots){if([Convert]::ToBase64String((ReadBytes $snapshot.address $snapshot.old.Length))-cne [Convert]::ToBase64String($snapshot.old)){throw 'Endpoint restoration readback mismatch'}}
  @{at=(Get-Date).ToString('o');event='restored';pid=$ClientPid} | ConvertTo-Json -Compress | Add-Content -LiteralPath $log
  Write-Output 'Original endpoints restored and verified.'
 }
 elseif($started){
  @{at=(Get-Date).ToString('o');event='client-exited';pid=$ClientPid} | ConvertTo-Json -Compress | Add-Content -LiteralPath $log
  Write-Output 'Test client exited; temporary memory changes no longer exist.'
 }
 [void][LoginEndpointTestMemory]::CloseHandle($handle)
}

