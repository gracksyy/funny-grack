function Invoke-LocalClientRedirections {
 param([string]$PatchPath,[int[]]$ClientPids,[int]$Seconds,[string]$LogPrefix,[int]$ModeratorClientPid=0,[switch]$LocalModerationWeb,[string]$ServerBaseUrl='http://127.0.0.1:18744/',[string]$GameplayHost='',[switch]$RequireVmServer,[switch]$UntilClientExit)
 if($ClientPids.Count -lt 1 -or $ClientPids.Count -gt 3 -or @($ClientPids|Select-Object -Unique).Count -ne $ClientPids.Count){throw 'Supply one to three distinct client PIDs'}
 if($Seconds -lt 10 -or $Seconds -gt 180){throw 'Bounded test must be 10 to 180 seconds'}
 if($ModeratorClientPid -and $ModeratorClientPid -notin $ClientPids){throw 'Moderator PID must be among the test clients'}
 if($ClientPids.Count -eq 1){
  $taskPatchArgs=@{ClientPid=$ClientPids[0];Seconds=$Seconds;Apply=$true}
  if($ModeratorClientPid){$taskPatchArgs.ModeratorLogin=$true}
  if($LocalModerationWeb){$taskPatchArgs.LocalModerationWeb=$true}
  if($ServerBaseUrl -cne 'http://127.0.0.1:18744/'){$taskPatchArgs.ServerBaseUrl=$ServerBaseUrl}
  if($GameplayHost){$taskPatchArgs.GameplayHost=$GameplayHost}
  if($RequireVmServer){$taskPatchArgs.RequireVmServer=$true}
  if($UntilClientExit){$taskPatchArgs.UntilClientExit=$true}
  & $PatchPath @taskPatchArgs;return
 }
 $taskWorkers=@();$taskFailed=$false;$taskActive=@{}
 try{
  foreach($taskTarget in $ClientPids){
   $taskLifecycle=$LogPrefix+'.'+$taskTarget+'.endpoints.jsonl'
   $taskJob=Start-Job -ScriptBlock {
    param($taskPatch,$taskPid,$taskSeconds,$taskLog,$taskModerator,$taskLocalWeb,$taskServerUrl,$taskGameHost,$taskRequireVm,$taskUntilExit)
    $ErrorActionPreference='Stop'
    $taskPatchArgs=@{ClientPid=$taskPid;Seconds=$taskSeconds;Apply=$true;LifecycleLog=$taskLog}
    if($taskModerator){$taskPatchArgs.ModeratorLogin=$true}
    if($taskLocalWeb){$taskPatchArgs.LocalModerationWeb=$true}
    if($taskServerUrl -cne 'http://127.0.0.1:18744/'){$taskPatchArgs.ServerBaseUrl=$taskServerUrl}
    if($taskGameHost){$taskPatchArgs.GameplayHost=$taskGameHost}
    if($taskRequireVm){$taskPatchArgs.RequireVmServer=$true}
    if($taskUntilExit){$taskPatchArgs.UntilClientExit=$true}
    & $taskPatch @taskPatchArgs
   } -ArgumentList $PatchPath,$taskTarget,$Seconds,$taskLifecycle,($taskTarget -eq $ModeratorClientPid),([bool]$LocalModerationWeb),$ServerBaseUrl,$GameplayHost,([bool]$RequireVmServer),([bool]$UntilClientExit)
   $taskWorkers+=@{job=$taskJob;pid=$taskTarget}
  }
  $taskReported=$false
  do{
   foreach($taskWorker in $taskWorkers){
    $taskWorkerErrors=@()
    $taskOutput=@(Receive-Job -Job $taskWorker.job -ErrorAction SilentlyContinue -ErrorVariable taskWorkerErrors)
    foreach($taskLine in $taskOutput){
     Write-Output $taskLine
     if($taskLine -is [string] -and $taskLine.StartsWith('Local login, REST and gameplay host verified active')){$taskActive[$taskWorker.pid]=$true}
    }
    if($taskWorkerErrors.Count -or $taskWorker.job.State -eq 'Failed'){$taskFailed=$true}
   }
   if(!$taskReported -and $taskActive.Count -eq $ClientPids.Count -and !$taskFailed){
    if($ClientPids.Count -eq 2){Write-Output 'Both clients have verified local endpoints. Use distinct saved characters in the same Local Room.'}
    else{Write-Output 'All three clients have verified local endpoints. Use distinct saved characters; the observer should enter Local Room after the pair starts its pose.'}
    $taskReported=$true
   }
   $taskRunning=@($taskWorkers|Where-Object {$_.job.State -notin @('Completed','Failed','Stopped')})
   if($taskRunning.Count){Start-Sleep -Milliseconds 250}
  }while($taskRunning.Count)
  if($taskFailed){throw 'A client redirection worker failed. Other workers completed their restoration before service cleanup; inspect the per-client endpoint logs.'}
 }finally{
  # Never terminate a running patch job: its finally owns restoration.
  foreach($taskWorker in $taskWorkers){
   [void](Wait-Job -Job $taskWorker.job)
   Receive-Job -Job $taskWorker.job -ErrorAction SilentlyContinue
   Remove-Job -Job $taskWorker.job
  }
 }
}
