function Get-ClientEndpointPlan {
 param([string]$ServerBaseUrl='http://127.0.0.1:18744/',[string]$GameplayHost='',[switch]$ModeratorLogin,[switch]$LocalModerationWeb)
 $taskUri=$null
 if(![Uri]::TryCreate($ServerBaseUrl,[UriKind]::Absolute,[ref]$taskUri) -or $taskUri.Scheme -notin @('http','https') -or $taskUri.UserInfo -or $taskUri.Query -or $taskUri.Fragment -or $taskUri.AbsolutePath -ne '/'){throw 'ServerBaseUrl must be an HTTP(S) root URL with no credentials, query or fragment'}
 $taskBase=$taskUri.GetLeftPart([UriPartial]::Authority)+'/'
 $taskGameHost=if($GameplayHost){$GameplayHost}else{$taskUri.DnsSafeHost}
 if($taskGameHost -notmatch '^[A-Za-z0-9.-]{1,15}$'){throw 'Gameplay hostname must be IPv4 or a hostname of at most 15 ASCII characters'}
 $taskSpecs=@(
  @{name='login';rva=0x64fc4d0;offset=8;expected='https://login.3dxchat.com/login2';replacement=($taskBase+$(if($ModeratorLogin){'login3'}else{'login2'}))},
  @{name='REST';rva=0x64e5a88;offset=0;expected='https://rest.3dxchat.com/';replacement=$taskBase},
  @{name='gameplay';rva=0x64b0af8;offset=0;expected='rlt.3dxchat.com';replacement=$taskGameHost},
  @{name='world';rva=0x64fcfe0;offset=0;expected='http://usercontent.3dxchat.com/worlds';replacement=($taskBase+'worlds')}
 )
 if($LocalModerationWeb -or $ModeratorLogin){$taskSpecs+=@{name='moderation web';rva=0x64fc3e0;offset=0x10;expected='https://3dxchat.com/core/';replacement=$taskBase}}
 foreach($taskSpec in $taskSpecs){if($taskSpec.replacement.Length -gt $taskSpec.expected.Length){throw ('The '+$taskSpec.name+' URL cannot fit this client build. Use port 80/443 without an explicit port, or a shorter hostname.')}}
 return [pscustomobject]@{BaseUrl=$taskBase;GameplayHost=$taskGameHost;Specs=$taskSpecs}
}
