# Actual email/password login

The VM prototype now verifies the credentials supplied through the game's existing login screen. This extends the separate-VM work rather than the older dummy-login fixtures, whose behavior remains available unchanged.

## Native request recovery

login2's request coroutine normalizes email/password with its existing space removal and String.Trim calls and invokes `xq.F` at `0x1807bc1e0`. That wrapper loads the recovered VM resource and label `bVq@91,CVW` (literal index 12865). The same ASCII85/XOR label decoder yields position 37370. The program is 6221 bytes at offset 37958, with four arguments, 79 locals and 1069 decoded instructions. `inspect-login-request-vm.cjs` saves the header/instruction listing. The opcode-table extractor was corrected to handle `xor r8d,r8d` as operand kind zero, which is needed for ldc.i4.s.

The JSON payload contains raw email/password arguments plus hardware/device information. The credential transform is XOR of UTF-16 code units with `GL`-prefixed 32-character key, then two-key TripleDES CBC with fixed UTF-8 key `abcdefghijklmnop` and IV key1[0:8], then Base64 and a second XOR, then AES-256 CBC with a fixed 32-character UTF-8 key and 16-character key2 IV, then Base64 and a final XOR. Both ciphers use default PKCS7 padding. The form carries payload/hash/key1/key2/ver=4. MD5 covers payload + its character length + key1 + key2 + a fixed suffix. The checksum is protocol compatibility, not password storage or a secure network MAC.

`login-request-codec.cjs` implements the inverse and returns only email/password. `check-login-request-codec.ps1` independently generates .NET TripleDES/Rijndael/XOR/checksum fixtures, including supplementary Unicode, and checks Node decoding. The actual request must preserve control characters: the tests use URL-encoded forms for login because browser FormData normalizes line endings inside text parts, changing this checksum. The form parser also accepts unmodified native multipart text.

## Account implementation

`local-account-store.cjs` persists normalized email, a salted scrypt password record (N=32768,r=8,p=1), role and imported ownership metadata in accounts.json. New characters store their account ID alongside the existing appearance record. Global storage supports 48 characters, while each login profile still exposes at most three owned slots. Existing records are imported without rewriting their appearance data; passwords start unset and login-disabled until the VM administrator sets them.

Bearer tokens are opaque three-part strings compatible with login.F. They are kept in memory, scoped to account-owned character IDs, and expire after eight hours. Password reset revokes the account's tokens; every approved gameplay frame rechecks authorization. Profiles, friend lists, character writes, room entry and moderation honor the same ownership rules. Public social reads of peer profile/appearance still work. Login URL and claimed role/owner fields do not grant authority.

The management CLI prompts for passwords without echo, reads an on-VM management key, and invokes protected account create/list/password endpoints over loopback. No public registration or email service is added. Login has a bounded source-based request/failure window and at most four concurrent password checks. Hardware IDs, device names and old client tokens from the native payload are discarded. Logs exclude credentials, bearer tokens, request payloads and management keys.

`accounts-check.cjs` verifies encoded credential login, failed passwords, case handling, disabled imports, protected creation and listing, duplicate rejection, independent accounts, three-slot limits, ownership despite supplied owner fields, REST/TCP impersonation denial, role-URL escalation denial, cross-account chat, password reset/revocation and persistence/reload. `vm-check.cjs` verifies these accounts alongside VM HTTP/TCP/world/profile/friend paths and source access rules. Live game-client sign-in and Ubuntu container execution remain pending; the synthetic and independent .NET results do not claim a completed visual test.
