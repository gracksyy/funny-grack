const http = require('node:http');
const fs = require('node:fs');
const pathModule = require('node:path');
const {decodeLegacyAvatar} = require('./avatar-legacy-codec.cjs');
const {createCharacterStore} = require('./local-character-store.cjs');
const {parseForm} = require('./local-http-form.cjs');
const {buildProfile, buildLoginResponse, createLocalProfile} = require('./local-login-profile.cjs');

function loadDefaultAvatars() {
  const presets = pathModule.join(__dirname, '../../OLDSERVER/peppersprayData/presets');
  const result = {};
  for (const [sex, name] of [['m','Male'], ['f','Female']]) {
    const data = fs.readFileSync(pathModule.join(presets, `default${name}.base64`), 'utf8').trim();
    if (!decodeLegacyAvatar(data).startsWith('<head_scale>')) throw new Error('Unexpected bundled default avatar');
    result[sex] = data;
  }
  return result;
}

function createLoginService({profile = createLocalProfile(), log = () => {}, defaultAvatars = loadDefaultAvatars(), characterStore, editorHandshake=false, worldDownloads=false, extraHandler,friendBridge=null,profileBridge=null,moderationBridge=null,allowRemote=()=>true,healthDetails={},accountBridge=null} = {}) {
  profile = {...profile, characters:profile.characters ?? []};
  buildProfile(profile); // Validate before accepting connections.
  const store = characterStore ?? createCharacterStore({defaultAvatars});
  const currentProfile = () => characterStore || !profile.characters.length ? {...profile, characters:store.characters()} : profile;
  const requestToken=request=>request.headers.authorization?.startsWith('Bearer ')?request.headers.authorization.slice(7):'';
  const authorized=request=>moderationBridge?moderationBridge.roles.validToken(requestToken(request)):requestToken(request)===profile.token;
  const mayAct=(request,uid)=>!moderationBridge||moderationBridge.roles.mayAct(requestToken(request),uid);
  return http.createServer((request, response) => {
    if(!allowRemote(request.socket.remoteAddress)){request.resume();response.writeHead(403,{'Content-Type':'text/plain','Cache-Control':'no-store'});response.end('Client address is not allowed');log({event:'access-denied'});return;}
    if(extraHandler && extraHandler(request,response))return;
    const path = new URL(request.url, 'http://127.0.0.1').pathname;
    const send = (status, body, contentType = 'text/plain; charset=utf-8') => {
      response.writeHead(status, {'Content-Type':contentType, 'Cache-Control':'no-store'});
      response.end(body);
      // Deliberately exclude query, headers, form body, envelope and token.
      log({method:request.method, path, status, bytes:Buffer.byteLength(body)});
    };
    if(accountBridge&&accountBridge.management(request,send))return;
    if (request.method === 'GET' && path === '/health') {
      request.resume();
      return send(200, JSON.stringify({mode:'login-bootstrap', characterSlots:currentProfile().characters.length, ...(editorHandshake?{editorHandshake:true,fixturePid:process.pid,worldDownloads}: {}),...healthDetails}), 'application/json');
    }
    if(moderationBridge&&request.method==='GET'&&path==='/moderator.php'){
      request.resume();
      return send(200,'<!doctype html><html lang="en"><meta charset="utf-8"><title>Local moderation</title><h1>Local moderation</h1><p>Ban is not implemented. No ban has been applied.</p><p>Return to the game to use chat Mute/Unmute or simple Kick.</p></html>','text/html; charset=utf-8');
    }
    if(moderationBridge&&request.method==='POST'&&path==='/ban'){
      // Native callback appends the response to moderator.php?token=. This
      // public marker is neither an account token nor permission to act.
      request.resume();return send(moderationBridge.roles.isModeratorToken(requestToken(request))?200:403,'local-ban-disabled');
    }
    if (request.method === 'GET' && ['/getmoney','/showreward'].includes(path)) {
      request.resume();
      return send(200, '0'); // Money parses an integer; showreward skips UI on exact '0'.
    }
    if (request.method !== 'POST' || !['/login2', '/offlineMsgCheck', '/offlineMsgGet', '/offlineNotifications', '/getdefaultchar', '/favrooms', '/checkname', '/createchar', '/savechar', '/loadfriends', '/onlinefriends', '/getignores',...(friendBridge?['/friendrequest','/deletefriend']:[]),...(profileBridge?['/getprofile','/saveprofile']:[]),...(moderationBridge?['/login3','/mute']:[])].includes(path)) {
      request.resume();
      return send(404, 'Unknown local endpoint');
    }
    // This loopback fixture accepts dummy login inputs; it does not validate accounts.
    // Discard form bytes rather than parsing or retaining credentials.
    let bytes = 0, rejected = false;
    const chunks = [];
    const needsForm = ['/getdefaultchar', '/favrooms', '/checkname', '/createchar', '/savechar', '/offlineMsgGet', '/offlineNotifications',...(friendBridge?['/friendrequest','/deletefriend','/loadfriends','/onlinefriends']:[]),...(profileBridge?['/getprofile','/saveprofile']:[]),...(moderationBridge?['/mute']:[]),...(accountBridge?['/login2','/login3']:[])].includes(path);
    request.on('data', chunk => {
      bytes += chunk.length;
      if (bytes > 1024 * 1024 && !rejected) { rejected = true; send(413, 'Request too large'); }
      if (needsForm && !rejected) chunks.push(chunk);
    });
    request.on('end', async () => {
      if (rejected) return;
      let form;
      if (needsForm) {
        try { form = parseForm(Buffer.concat(chunks), request.headers['content-type']); }
        catch { return send(accountBridge&&['/login2','/login3'].includes(path)?200:400,accountBridge&&['/login2','/login3'].includes(path)?'answer=fail\n':path === '/createchar' ? '{}' : ''); }
      }
      if(accountBridge&&['/login2','/login3'].includes(path)){
        try{const result=await accountBridge.login(form,request.socket.remoteAddress);if(result.status===429)return send(429,'answer=fail\n');return send(200,result.profile?buildLoginResponse(result.profile):'answer=fail\n');}catch{return send(200,'answer=fail\n');}
      }
      if (path === '/offlineMsgCheck') return send(200, '[]', 'application/json');
      if (['/offlineMsgGet','/offlineNotifications'].includes(path)) {
        if(!authorized(request)||!mayAct(request,form.get('uid')))return send(403,'[]','application/json');
        if(!store.characters().some(character=>character.id===form.get('uid')))return send(404,'[]','application/json');
        // Both current coroutines parse JArray and exit when Count is zero.
        return send(200,'[]','application/json');
      }
      if(friendBridge&&['/friendrequest','/deletefriend','/loadfriends','/onlinefriends'].includes(path)){
        if(!authorized(request))return send(403,'error');
        const uid=form.get(path==='/loadfriends'||path==='/onlinefriends'?'id':'uid'),friends=friendBridge.store.list(uid);
        if(!mayAct(request,uid))return send(403,'error');
        if(!friends)return send(400,'error');
        if(path==='/loadfriends')return send(200,JSON.stringify(friends),'application/json');
        if(path==='/onlinefriends')return send(200,JSON.stringify(friends.filter(c=>friendBridge.isConnected(c.id)).map(c=>c.id)),'application/json');
        const fid=form.get('fid');if(fid===uid||!friendBridge.store.list(fid))return send(400,'error');
        try{
          if(path==='/friendrequest'){
            const result=friendBridge.store.request(uid,fid);
            if(result.kind==='requested')friendBridge.notice(fid,'FriendRequest',uid);
            if(result.kind==='accepted')friendBridge.notice(result.requester,'FriendAccept',uid);
          }else if(friendBridge.store.remove(uid,fid)){
            friendBridge.notice(fid,'unfriend',uid);friendBridge.notice(uid,'unfriend',fid);
          }
          return send(200,'ok');
        }catch{return send(500,'error');}
      }
      if (['/loadfriends','/onlinefriends'].includes(path)) return send(200, '[]', 'application/json');
      if(profileBridge&&['/getprofile','/saveprofile'].includes(path)){
        if(!authorized(request))return send(403,'error');
        const id=form.get('id'),value=profileBridge.store.get(id);if(!value)return send(404,'error');
        if(path==='/getprofile')return send(200,JSON.stringify(value),'application/json');
        if(!mayAct(request,id))return send(403,'error');
        try{if(!profileBridge.store.save(id,form.get('profile')))return send(400,'error');profileBridge.updated(id);return send(200,'ok');}catch{return send(500,'error');}
      }
      if(moderationBridge&&path==='/mute'){
        const result=moderationBridge.roles.mute(requestToken(request),form.get('uid'),form.get('userid'),form.get('mode'),form.get('time'));
        if(result.status===200)moderationBridge.notify(result.target,result.time);
        return send(result.status,result.status===200?'ok':'error');
      }
      if (path === '/getignores') return send(200, '{"blacklist":[],"ignoredBy":[]}', 'application/json');
      if (path === '/getdefaultchar') {
        // Empty error bodies avoid handing arbitrary error text to applyCharData.
        if (!Object.hasOwn(defaultAvatars, form.get('sex'))) return send(400, '');
        return send(200, defaultAvatars[form.get('sex')]);
      }
      if (path === '/favrooms') {
        if (form.get('action') !== 'get') return send(400, '');
        // Current consumer splits commas then Int32.Parse on every item.
        // Zero is a local placeholder, not a claim about production empty lists.
        return send(200, '0');
      }
      if (['/checkname', '/createchar', '/savechar'].includes(path)) {
        if (!characterStore && profile.characters.length) return send(409, path === '/createchar' ? '{}' : '');
        // Only this service's synthetic session can mutate its character store.
        if (!authorized(request)|| (moderationBridge&&(path==='/savechar'? !mayAct(request,form.get('id')):!(accountBridge&&moderationBridge.roles.canCreate(requestToken(request))))))
          return send(403, path === '/createchar' ? '{}' : '');
        if (path === '/checkname') return send(200, store.checkName(form.get('name')));
        try {
          if (path === '/createchar') {
            const result = accountBridge?moderationBridge.roles.createCharacter(requestToken(request),form.get('name'),form.get('sex')):store.create(form.get('name'), form.get('sex'));
            return send(200, JSON.stringify(result.id ? {...result, token:requestToken(request)} : result), 'application/json');
          }
          // key is the client cache key. check is present but not interpreted;
          // production integrity validation is outside this local fixture.
          if (!form.get('check') || form.get('check').length > 256) return send(400, '');
          return send(200, store.save(form.get('id'), form.get('data'), form.get('key')) ? 'ok' : '');
        } catch { return send(500, path === '/createchar' ? '{}' : ''); }
      }
      send(200, buildLoginResponse(moderationBridge?moderationBridge.roles.login(path):currentProfile()));
    });
  });
}

if (require.main === module) {
  const defaultAvatars = loadDefaultAvatars();
  const characterStore = createCharacterStore({file:pathModule.join(__dirname, 'local-state/characters.json'), defaultAvatars});
  const server = createLoginService({defaultAvatars, characterStore, log:entry => console.log(JSON.stringify(entry))});
  server.listen(18744, '127.0.0.1', () => console.log('Local persistent-character login fixture: http://127.0.0.1:18744'));
}

module.exports = {createLoginService, loadDefaultAvatars};
