const path=require('node:path');
const fs=require('node:fs');
const {createLoginService,loadDefaultAvatars}=require('./local-login-service.cjs');
const {createCharacterStore}=require('./local-character-store.cjs');
const {createLocalProfile}=require('./local-login-profile.cjs');
const {createGameTcp}=require('./local-game-tcp.cjs');
const {createEditorWorld}=require('./local-editor-world.cjs');
const {createFriendStore}=require('./local-friend-store.cjs');
const {createProfileStore}=require('./local-profile-store.cjs');
const {createModeration}=require('./local-moderation.cjs');

function createEditorServices({characterStore,profile=createLocalProfile(),worldZip,log=()=>{},disconnectOnceAfterMs=null,roomTest=false,presence=false,avatarRelay=false,movementRelay=false,animationRelay=false,pairedDanceRelay=false,partnerUpRelay=false,poseRelay=false,departureTest=false,chatRelay=false,friendStore=null,profileStore=null,moderationTest=false,allowRemote=()=>true,healthDetails={},moderatorId=null,accountBridge=null}={}) {
  poseRelay=poseRelay||departureTest;
  partnerUpRelay=partnerUpRelay||poseRelay;
  pairedDanceRelay=pairedDanceRelay||partnerUpRelay;
  animationRelay=animationRelay||pairedDanceRelay;
  movementRelay=movementRelay||animationRelay;
  avatarRelay=avatarRelay||movementRelay||chatRelay||!!friendStore||!!profileStore||moderationTest||!!accountBridge;
  if(!characterStore)throw new Error('Explicit local character store required');
  const moderation=(moderationTest||accountBridge)?createModeration({profile,characters:()=>characterStore.characters(),moderatorId:moderatorId||characterStore.characters()[0]?.id,accounts:accountBridge?.store}):null;
  const httpLog=entry=>log({service:'http',...entry});
  const fixtureOwner='1000000099';
  // Virtual host advertises the existing test ZIP; it is not a saved character.
  const location={tag:201,value:[['n',{tag:11,value:'LocalHost'}],['i',{tag:11,value:fixtureOwner}],['room',{tag:11,value:'local-test-room'}],['show',{tag:7,value:0}],['players',{tag:7,value:0}],['title',{tag:11,value:'Local Room'}],['groupID',{tag:7,value:-1}]]};
  const tcp=createGameTcp({authorize:(token,uid)=>moderation?moderation.mayAct(token,uid):token===profile.token && characterStore.characters().some(c=>c.id===uid),log:entry=>log({service:'tcp',...entry}),resumeMs:departureTest?15000:120000,disconnectOnceAfterMs,sharedLocations:()=>roomTest?[location]:[],presence:presence||avatarRelay,avatarRelay,movementRelay,animationRelay,pairedDanceRelay,partnerUpRelay,poseRelay,chatRelay,friendStore,moderation,allowRemote,characterFor:uid=>characterStore.characters().find(c=>c.id===uid)});
  const extraHandler=worldZip?createEditorWorld({zip:worldZip,characterStore,token:profile.token,onJoinRoom:(uid,room)=>tcp.joinRoom(uid,room),log:httpLog,extraWorldOwners:roomTest?[fixtureOwner]:[],avatarData:avatarRelay,roles:moderation}):undefined;
  const http=createLoginService({profile,characterStore,editorHandshake:true,worldDownloads:!!worldZip,extraHandler,log:httpLog,friendBridge:friendStore?{store:friendStore,isConnected:uid=>tcp.isConnected(uid),notice:(uid,type,other)=>tcp.friendNotice(uid,type,other)}:null,profileBridge:profileStore?{store:profileStore,updated:uid=>tcp.profileUpdated(uid)}:null,moderationBridge:moderation?{roles:moderation,notify:(uid,time)=>tcp.muteNotice(uid,time)}:null,allowRemote,healthDetails,accountBridge});
  return {http,tcp,async close(){await tcp.close();http.closeAllConnections();if(http.listening)await new Promise(resolve=>http.close(resolve));}};
}
module.exports={createEditorServices};
if(require.main===module) {
  const delayIndex=process.argv.indexOf('--resume-delay-ms');
  const resumeDelayMs=delayIndex<0?45000:Number(process.argv[delayIndex+1]);
  if(!Number.isInteger(resumeDelayMs)||resumeDelayMs<15000||resumeDelayMs>120000)throw new Error('Resume delay must be 15000–120000 ms');
  const defaultAvatars=loadDefaultAvatars();
  const characterStore=createCharacterStore({file:path.join(__dirname,'local-state/characters.json'),defaultAvatars});
  const friendStore=process.argv.includes('--friend-test')?createFriendStore({file:path.join(__dirname,'local-state/friends.json'),characters:()=>characterStore.characters()}):null;
  const profileStore=process.argv.includes('--profile-test')?createProfileStore({file:path.join(__dirname,'local-state/profiles.json'),characters:()=>characterStore.characters()}):null;
  const worldZip=fs.readFileSync(path.join(__dirname,'../world-fixtures/test-world.zip'));
  const service=createEditorServices({characterStore,worldZip,log:entry=>console.log(JSON.stringify(entry)),disconnectOnceAfterMs:process.argv.includes('--resume-test')?resumeDelayMs:null,roomTest:process.argv.includes('--room-test'),presence:process.argv.includes('--presence-test'),avatarRelay:process.argv.includes('--avatar-test'),movementRelay:process.argv.includes('--movement-test'),animationRelay:process.argv.includes('--animation-test'),pairedDanceRelay:process.argv.includes('--paired-dance-test'),partnerUpRelay:process.argv.includes('--partner-up-test'),poseRelay:process.argv.includes('--pose-test'),departureTest:process.argv.includes('--departure-test'),chatRelay:process.argv.includes('--chat-test'),friendStore,profileStore,moderationTest:process.argv.includes('--moderation-test')});
  (async()=>{
    try {
      await new Promise((resolve,reject)=>{service.http.once('error',reject);service.http.listen(18744,'127.0.0.1',resolve);});
      await new Promise((resolve,reject)=>{service.tcp.server.once('error',reject);service.tcp.server.listen(8125,'127.0.0.1',resolve);});
      console.log('Local editor fixture ready: HTTP 127.0.0.1:18744, TCP 127.0.0.1:8125; local world downloads and single-player chat-room state enabled.');
    } catch {await service.close();console.error('Local editor fixture could not bind; listeners closed.');process.exitCode=1;}
  })();
  for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>service.close());
}
