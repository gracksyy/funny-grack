const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {promisify}=require('node:util');
const scrypt=promisify(crypto.scrypt);
const SCRYPT={N:32768,r:8,p:1,maxmem:64*1024*1024};
function emailAddress(value){if(typeof value!=='string'||value.length>254||! /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(value.trim()))throw Error('Invalid account email');return value.trim().toLowerCase();}
function passwordValue(value){if(typeof value!=='string'||value.length<8||value.length>128||value.replace(/ +/g,'').trim()!==value||/[\x00-\x1f\x7f]/.test(value))throw Error('Password must be 8-128 characters without spaces or controls');return value;}
async function passwordRecord(password){const salt=crypto.randomBytes(16).toString('hex'),hash=await scrypt(passwordValue(password),salt,32,SCRYPT);return {algorithm:'scrypt',N:32768,r:8,p:1,salt,hash:hash.toString('hex')};}
function createAccountStore({file,characterStore,moderatorId,moderationEnabled=true,maxAccounts=16}={}){
 if(!file||!characterStore||!Number.isInteger(maxAccounts)||maxAccounts<2||maxAccounts>32)throw Error('Explicit account store and character provider required');
 let state={version:1,accounts:[]};const tokens=new Map();
 const allChars=()=>characterStore.characters();
 function validate(s){
  if(s?.version!==1||!Array.isArray(s.accounts)||s.accounts.length>maxAccounts)throw Error('Invalid account store');
  const ids=new Set(),emails=new Set(),seed=new Set(),discord=new Set();
  for(const a of s.accounts){
   if(typeof a.id!=='string'||! /^[A-Za-z0-9_-]{1,64}$/.test(a.id)||ids.has(a.id)||emailAddress(a.email)!==a.email||emails.has(a.email)||!['user','moderator'].includes(a.role)||!Array.isArray(a.seedCharacters)||a.seedCharacters.length>3)throw Error('Invalid account record');
   ids.add(a.id);emails.add(a.email);
   if(a.discordId!==undefined){if(!/^[0-9]{17,20}$/.test(a.discordId)||discord.has(a.discordId))throw Error('Invalid Discord owner');discord.add(a.discordId);}
   for(const id of a.seedCharacters){if(seed.has(id)||!allChars().some(c=>c.id===id&&!c.accountId))throw Error('Invalid imported character owner');seed.add(id);}
   if(a.password!==null){const p=a.password;if(p?.algorithm!=='scrypt'||p.N!==32768||p.r!==8||p.p!==1||! /^[a-f0-9]{32}$/.test(p.salt)||! /^[a-f0-9]{64}$/.test(p.hash))throw Error('Invalid password record');}
   if(allChars().filter(c=>c.accountId===a.id||a.seedCharacters.includes(c.id)).length>3)throw Error('Account exceeds three character slots');
  }
  if(allChars().some(c=>c.accountId&&!ids.has(c.accountId)))throw Error('Character has unknown account owner');
 }
 function commit(next){validate(next);fs.mkdirSync(path.dirname(file),{recursive:true});const temp=file+'.'+crypto.randomBytes(8).toString('hex')+'.tmp';try{fs.writeFileSync(temp,JSON.stringify(next,null,2)+'\n',{flag:'wx',mode:0o600});fs.renameSync(temp,file);}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}state=next;}
 if(fs.existsSync(file)){state=JSON.parse(fs.readFileSync(file,'utf8'));validate(state);}
 else{
  const imported=allChars().filter(c=>!c.accountId);if(!imported.some(c=>c.id===moderatorId))throw Error('Imported moderator character required');
  commit({version:1,accounts:[{id:'prototype-user',email:'offline@example.com',role:'user',password:null,seedCharacters:imported.filter(c=>c.id!==moderatorId).map(c=>c.id)},{id:'prototype-moderator',email:'moderator@example.com',role:'moderator',password:null,seedCharacters:[moderatorId]}]});
 }
 const own=a=>allChars().filter(c=>c.accountId===a.id||a.seedCharacters.includes(c.id));
 function accountForToken(token){const session=tokens.get(token);if(!session||session.until<=Date.now()){tokens.delete(token);return null;}return state.accounts.find(a=>a.id===session.accountId)||null;}
 function tokenFor(a){for(const [token,s] of tokens)if(s.accountId===a.id&&s.until>Date.now())return token;const token='offline.account.'+crypto.randomBytes(24).toString('hex');tokens.set(token,{accountId:a.id,until:Date.now()+8*3600000});return token;}
 const info=a=>({id:a.id,email:a.email,role:a.role,passwordSet:a.password!==null,...(a.discordId?{discordId:a.discordId}:{}),characters:own(a).map(c=>({id:c.id,name:c.name,sex:c.sex}))});
 return {
  list:()=>state.accounts.map(info),
  reserveDiscord(email,discordId){
   const canonical=emailAddress(email);if(typeof discordId!=='string'||!/^[0-9]{17,20}$/.test(discordId))throw Error('Invalid Discord owner');
   const linked=state.accounts.find(a=>a.discordId===discordId);if(linked){if(linked.email!==canonical)throw Error('Already linked');return info(linked);}
   if(state.accounts.some(a=>a.email===canonical)||state.accounts.length>=maxAccounts)throw Error('Email already in use or capacity reached');
   const a={id:crypto.randomUUID(),email:canonical,role:'user',password:null,seedCharacters:[],discordId};commit({...state,accounts:[...state.accounts,a]});return info(a);
  },
  validToken:token=>!!accountForToken(token),
  mayAct(token,uid){const a=accountForToken(token);return !!a&&own(a).some(c=>c.id===uid);},
  isModerator(token,uid){const a=accountForToken(token);return moderationEnabled&&a?.role==='moderator'&&own(a).some(c=>c.id===uid);},
  isModeratorToken(token){return moderationEnabled&&accountForToken(token)?.role==='moderator';},
  login(){throw Error('Email/password authentication required');},
  canCreate(token){const a=accountForToken(token);return !!a&&own(a).length<3;},
  createCharacter(token,name,sex){const a=accountForToken(token);if(!a)return {error:'unauthorized'};if(own(a).length>=3)return {error:'slots_full'};return characterStore.create(name,sex,a.id);},
  async authenticate(email,password){
   let canonical;try{canonical=emailAddress(email);}catch{return null;}
   if(typeof password!=='string'||password.length>128)return null;
   const a=state.accounts.find(a=>a.email===canonical),p=a?.password;
   const actual=await scrypt(password,p?.salt||'0'.repeat(32),32,SCRYPT),expected=Buffer.from(p?.hash||'0'.repeat(64),'hex');
   const current=a&&state.accounts.find(item=>item.id===a.id);
   if(!p||current?.password?.hash!==p.hash||!crypto.timingSafeEqual(actual,expected))return null;
   return {token:tokenFor(current),moderator:moderationEnabled&&current.role==='moderator',characters:own(current)};
  },
  async create(email,password,role='user'){
   const canonical=emailAddress(email);if(!['user','moderator'].includes(role))throw Error('Invalid role');
   if(state.accounts.some(a=>a.email===canonical)||state.accounts.length>=maxAccounts)throw Error('Duplicate account or capacity reached');
   const record=await passwordRecord(password);
   if(state.accounts.some(a=>a.email===canonical)||state.accounts.length>=maxAccounts)throw Error('Duplicate account or capacity reached');
   const a={id:crypto.randomUUID(),email:canonical,role,password:record,seedCharacters:[]};commit({...state,accounts:[...state.accounts,a]});return info(a);
  },
  async setPassword(email,password){const canonical=emailAddress(email),a=state.accounts.find(a=>a.email===canonical);if(!a)throw Error('Unknown account');const record=await passwordRecord(password);commit({...state,accounts:state.accounts.map(item=>item.id===a.id?{...item,password:record}:item)});for(const [token,s] of tokens)if(s.accountId===a.id)tokens.delete(token);return info(state.accounts.find(item=>item.id===a.id));}
 };
}
module.exports={createAccountStore};
