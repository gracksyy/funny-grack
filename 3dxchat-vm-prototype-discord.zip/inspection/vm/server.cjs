const fs=require('node:fs'),path=require('node:path'),net=require('node:net');
const {createEditorServices}=require('../startup/local-editor-service.cjs');
const {createCharacterStore}=require('../startup/local-character-store.cjs');
const {loadDefaultAvatars}=require('../startup/local-login-service.cjs');
const {createFriendStore}=require('../startup/local-friend-store.cjs');
const {createProfileStore}=require('../startup/local-profile-store.cjs');
const {createAccountStore}=require('../startup/local-account-store.cjs');
const {createAccountBridge}=require('../startup/account-bridge.cjs');
const ROOT=path.resolve(__dirname,'../..');
const keys=['listenAddress','httpPort','tcpPort','allowedClients','dataDirectory','worldFile','moderationEnabled','moderatorId'];
function validateConfig(config){
 if(!config||typeof config!=='object'||Array.isArray(config)||Object.keys(config).some(k=>!keys.includes(k))||keys.some(k=>!Object.hasOwn(config,k)))throw Error('Invalid VM configuration keys');
 if(!net.isIP(config.listenAddress))throw Error('Listen address must be an IP literal');
 for(const p of ['httpPort','tcpPort'])if(!Number.isInteger(config[p])||config[p]<1||config[p]>65535)throw Error('Invalid listener port');
 if(config.httpPort===config.tcpPort)throw Error('Listener ports must differ');
 if(!Array.isArray(config.allowedClients)||config.allowedClients.length>32||config.allowedClients.some(a=>typeof a!=='string'||!net.isIP(a)))throw Error('Allowed clients must be IP literals');
 for(const p of ['dataDirectory','worldFile'])if(typeof config[p]!=='string'||!config[p]||path.isAbsolute(config[p])||config[p].split(/[\\/]/).some(part=>part==='..'))throw Error('Data and world paths must stay inside the package');
 if(typeof config.moderationEnabled!=='boolean'||typeof config.moderatorId!=='string'||!/^\d+$/.test(config.moderatorId))throw Error('Invalid moderator configuration');
 return config;
}
function accessPolicy(config){
 const allowed=new Set(['127.0.0.1','::1',...config.allowedClients.map(a=>a.toLowerCase().replace(/^::ffff:/,''))]);
 return address=>{if(typeof address!=='string')return false;const value=address.toLowerCase().replace(/^::ffff:/,'');return allowed.has(value);};
}
function createVmServices(config,{root=ROOT,log=()=>{}}={}){
 validateConfig(config);
 const data=path.resolve(root,config.dataDirectory);
 const charactersFile=path.join(data,'characters.json');
 if(!fs.existsSync(charactersFile))throw Error('Seed characters.json is required in the data directory');
 const characterStore=createCharacterStore({file:charactersFile,defaultAvatars:loadDefaultAvatars(),maxCharacters:48});
 if(!characterStore.characters().length)throw Error('At least one seeded character is required');
 const friendStore=createFriendStore({file:path.join(data,'friends.json'),characters:()=>characterStore.characters()});
 const profileStore=createProfileStore({file:path.join(data,'profiles.json'),characters:()=>characterStore.characters()});
 const accounts=createAccountStore({file:path.join(data,'accounts.json'),characterStore,moderatorId:config.moderatorId,moderationEnabled:config.moderationEnabled});
 const accountBridge=createAccountBridge({store:accounts,keyFile:path.join(data,'account-admin.key')});
 const worldZip=fs.readFileSync(path.resolve(root,config.worldFile));
 if(worldZip.length<4||worldZip[0]!==0x50||worldZip[1]!==0x4b)throw Error('Configured world must be a ZIP fixture');
 return createEditorServices({characterStore,friendStore,profileStore,worldZip,roomTest:true,poseRelay:true,chatRelay:true,moderationTest:config.moderationEnabled,moderatorId:config.moderatorId,accountBridge,allowRemote:accessPolicy(config),log,healthDetails:{deploymentMode:'vm-prototype',serverId:'3dxchat-vm-v1',tcpPort:config.tcpPort,moderationEnabled:config.moderationEnabled,passwordLogin:true,accountCharacterSlots:3}});
}
async function startVm(config,{root=ROOT,log=()=>{}}={}){
 const service=createVmServices(config,{root,log});
 try{
  for(const [server,port] of [[service.http,config.httpPort],[service.tcp.server,config.tcpPort]])await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,config.listenAddress,()=>{server.removeListener('error',reject);resolve();});});
  log({event:'vm-ready',httpPort:config.httpPort,tcpPort:config.tcpPort,remoteClientRules:config.allowedClients.length});
  return service;
 }catch(error){await service.close();throw error;}
}
module.exports={validateConfig,accessPolicy,createVmServices,startVm};
if(require.main===module){
 const index=process.argv.indexOf('--config'),configFile=index<0?path.join(ROOT,'server-config.json'):path.resolve(process.argv[index+1]||'');
 const log=entry=>console.log(JSON.stringify({at:new Date().toISOString(),...entry}));
 (async()=>{
  if(Number(process.versions.node.split('.')[0])<22)throw Error('Node 22 or later required');
  const config=validateConfig(JSON.parse(fs.readFileSync(configFile,'utf8')));
  const service=await startVm(config,{root:path.dirname(configFile),log});let closing=false;
  const close=async()=>{if(closing)return;closing=true;await service.close();log({event:'vm-stopped'});};
  for(const signal of ['SIGINT','SIGTERM'])process.on(signal,close);
 })().catch(error=>{console.error(JSON.stringify({event:'startup-failed',code:error.code||'configuration-or-state'}));process.exitCode=1;});
}
