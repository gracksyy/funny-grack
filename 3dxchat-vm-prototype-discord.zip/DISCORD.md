# Discord account management

Optional service for guild `1557006035812753498`. `/register email` creates a disabled ordinary account linked to the invoking Discord user. `/reset-password` issues a ten-minute single-use password setup link. `/account` lists that user's account and characters. `/staff-reset user` lets explicitly authorized staff issue a link for a linked user. Replies are ephemeral; passwords are entered on HTTPS, never in Discord commands. Emails are login identifiers, not verified email addresses. Existing unlinked accounts cannot be claimed through Discord; moderator roles remain assigned using the VM administrator CLI.

Discord ownership persists in accounts.json. A reserved account consumes one of the prototype's 16 slots even before password setup. Links grant password-reset access: keep them private. A new link invalidates its predecessor; restart invalidates all pending links. Password changes revoke game sessions. Audit logs contain operations and Discord IDs, not credentials or links.

## Preserve existing VM progress

Close clients, stop your current server, and back up the entire data directory. Extract this ZIP separately. Copy its `inspection/`, `Dockerfile`, `.dockerignore`, `compose.discord.yaml`, `discord-config.example.json`, and `DISCORD.md` into your current deployment. Preserve existing `data/`, `.env`, `server-config.json`, and `compose.yaml`. Do not overwrite VM progress with the ZIP's seed files. Existing accounts.json records are compatible.

Start the game server first to ensure data/account-admin.key exists:

```bash
sudo docker compose up -d --build
cp discord-config.example.json discord-config.json
nano discord-config.json
mkdir -p secrets
nano secrets/discord-token.txt
sudo chown 1000:1000 secrets/discord-token.txt
sudo chmod 600 secrets/discord-token.txt
```

Enter only the bot token in the file using the editor. Do not send it in chat or pass it as a command argument. The running service uses the application public key; the token is for the separate registration utility. Compose secrets are local read-only file mounts, not an encrypted vault. Protect the host files/backups. The bot mounts only the management key, not the account database.

## Discord application

Create a dedicated application at [Discord's developer portal](https://discord.com/developers/applications). Copy its Application ID and Public Key from General Information into discord-config.json. Guild ID is already `1557006035812753498`. Create/reset the token on the Bot page and save it in secrets/discord-token.txt. Invite the application to the guild through the portal's installation/OAuth2 settings with scopes `bot` and `applications.commands`. It needs no Administrator permission or privileged Gateway intents; commands arrive through signed HTTP interactions.

Set `staffUserIds` to the exact Discord user IDs permitted to reset others; leave empty to disable staff resets. Developer Mode enables Copy User ID. `/staff-reset` is hidden by default except from Discord administrators or users granted command access in the server's Integrations settings. The service also enforces staffUserIds: Discord Administrator alone cannot authorize it.

## HTTPS hostname

Create a DNS A record such as accounts.yourdomain.example pointing to the VM's public IPv4. Set publicUrl to that HTTPS origin with a trailing slash; leave bot port 8081. This hostname is independent of the game client's short URL buffers. The overlay publishes 8081 on host loopback only. The bot shares the game container network namespace to reach the management API on loopback; no game allowlist change is needed.

Install an HTTPS reverse proxy on the VM forwarding that hostname to 127.0.0.1:8081. For [Caddy on Ubuntu](https://caddyserver.com/docs/install#debian-ubuntu-raspbian), this example preserves the game's existing port 80 by disabling redirects and using the TLS-ALPN certificate challenge on 443:

```caddyfile
{
    auto_https disable_redirects
}

accounts.yourdomain.example {
    tls {
        issuer acme {
            disable_http_challenge
        }
    }
    reverse_proxy 127.0.0.1:8081
}
```

Replace the hostname. Open inbound destination TCP **443** for Discord, browsers and certificate issuance; keep game ports 80/8125 restricted to approved clients. Keep 8081 private. DNS must point directly to the VM; a CDN proxy can prevent this challenge. Don't add AAAA unless IPv6 also works. If another proxy already uses 443, add a hostname route there rather than replacing its configuration. Never log request bodies or authentication headers. See [Caddy TLS](https://caddyserver.com/docs/caddyfile/directives/tls) and [HTTPS options](https://caddyserver.com/docs/caddyfile/options#auto-https).

## Start and register commands

From the deployment directory, after replacing configuration placeholders:

```bash
sudo docker compose -f compose.yaml -f compose.discord.yaml --profile discord up -d --build
sudo docker compose -f compose.yaml -f compose.discord.yaml --profile discord exec discord-accounts node inspection/vm/discord-register.cjs
sudo docker compose -f compose.yaml -f compose.discord.yaml --profile discord logs --tail 30 discord-accounts
```

Registration creates/updates only these four named guild commands and preserves unrelated commands. For a reviewed Caddyfile:

```bash
sudo caddy validate --config /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

Visit `https://YOUR_HOSTNAME/health`; expect `{"ok":true}`. In Discord General Information, set **Interactions Endpoint URL** to `https://YOUR_HOSTNAME/interactions`. Discord verifies it with a signed PING. The service verifies Ed25519 signatures and timestamps, rejects replayed commands and wrong guilds, and defers private replies immediately before completing account operations. See [Discord interaction responses](https://docs.discord.com/developers/interactions/receiving-and-responding).

Use the combined Compose command for subsequent restarts/updates because the bot shares the game container's namespace. The default game deployment works without enabling this profile.

## First test and limits

Run `/register email:your-test-email@example.com`, open the private link, and set a unique test password. Sign in manually in the redirected game client with that email/password. `/account` should list your characters. Test `/reset-password`, and verify old links and the previous password stop working. Staff resets return the link privately to the authorized staff member, who must deliver it privately to the intended owner.

The setup page uses HTTPS; the game's existing HTTP/TCP testing transport remains unchanged. Local synthetic tests cover signatures, private reply delivery, persistent ownership, staff checks, single-use concurrent redemption, expiry and token revocation. Live Discord, public TLS and Docker/Ubuntu deployment await your application credentials and HTTPS hostname. No bot has been invited or commands published by this workspace.
