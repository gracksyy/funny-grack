# Prototype validation

Completed locally on 2026-10-06:

* Discord signed interactions, ping/replay/timestamp rejection, private deferred replies, persistent account ownership, unlinked-account protection, staff authorization, password-link origin checks, concurrent single-use redemption, expiry/invalidation and game-token revocation. Uses synthetic Ed25519 signatures/accounts and mocked Discord reply delivery. Live Discord/TLS/Docker deployment remains unverified.

* VM configuration and package-relative path validation; HTTP/TCP source-address denial.
* VM health fingerprint, role-aware room entry, world lookup and persistent profile/friend state.
* Native login request decoding against independent .NET TripleDES/Rijndael/XOR/checksum fixtures, including Unicode.
* Account management authorization, email/password verification, duplicate handling, three-slot ownership, cross-account REST/TCP denial, moderator roles, password reset and token revocation.
* Existing login, pose, departure, chat, clothing, profile and friend regressions.
* URL-buffer bounds, normalized IPv4 URLs, worker option forwarding, selected roles and endpoint-restoration lifecycle without client memory access.
* Packaged source/asset hashes, standalone packaged server startup, Windows PowerShell 5.1 CheckOnly connectivity and packaged account creation with password-stdin using synthetic credentials.

The package smoke test uses a temporary state copy; the bundled progress snapshot is unchanged and generated management keys are excluded. No live client credentials or game memory are inspected in these checks.

Docker is not installed in this workspace. Ubuntu container execution, actual game-client email/password acceptance and cross-VM gameplay require a manual test on your VM. The native credential codec has strong static and independent synthetic validation, but that is not a claim that the visual sign-in test is complete.
