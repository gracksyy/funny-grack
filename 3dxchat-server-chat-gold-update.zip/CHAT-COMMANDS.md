# Chat commands and test gold

This update handles native `/roll6`, `/roll12`, `/roll100` and bounded `/rollN` requests, and preserves/normalizes the client's encrypted `/me action` text. Dice are generated once on the server and delivered to the requested Local, Global or Private channel; Local rolls reach only the room and private rolls reach only sender/recipient. Group roll/name selection remains outside this update. The server rejects supplied results, sender identities, unsupported fields/channels, and invalid dice sizes without dropping the connection. Chat mutes also block dice and gold commands.

Moderators can type:

```text
/givegold LocalPeer 2500
/givegold 1000000001 2500
/givegold "Character Name" 2500
```

`/gold` is an alias with the same arguments. Choose an existing character by name or numeric character ID. Permission comes from the authenticated stored account's moderator role. The command reserves no permission from its text, supplied sender ID or login URL. Amounts must be whole numbers from 1 to 1,000,000; balances cannot exceed Int32.MaxValue. There is a three-second per-character grant cooldown. Grants can target offline characters; connected target characters receive a private notice. The command is not broadcast to the chat channel. Its sender gets a native confirmation/error popup because own-sender chat responses only acknowledge message IDs and do not display substituted response text.

Gold is **test currency on this custom server**. It is stored per account, shared by its character slots, in `data/gold.json`, along with up to 1,000 recent grant records. Each atomic save records the moderator account/character, target account/character, amount, before/after balance and transaction UUID. Additional metadata-only `gold-granted` entries appear in server logs. No credentials/chat bodies are logged. Password resets and server restarts preserve balances. Existing accounts start at zero unless a saved balance exists. This update does not implement gifting, purchases, paid name changes or spending; grants do not authorize those unimplemented endpoints.

GET `/getmoney` now returns the authenticated account's decimal integer balance and denies unauthenticated requests. The balance is persisted immediately, but instant native HUD refresh is not implemented: close/reopen the game and log in again to fetch it. No invented gold-update event is sent to the client. Gold commands require the account-enabled VM server; classic dummy-login fixtures report that gold grants are unavailable.

## Update the VM

Close clients and stop the server before replacing code. Back up the entire data folder. The **server update ZIP** contains only `inspection/` server code and documents; extract it into the existing deployment folder. Preserve `data/`, server-config.json, .env, discord-config.json, secrets, and your Caddy configuration. Do not overwrite VM progress with a full bundle's seed data.

For game-only deployment:

```bash
sudo docker compose up -d --build
```

With Discord enabled:

```bash
sudo docker compose -f compose.yaml -f compose.discord.yaml --profile discord up -d --build
```

The Windows EXE connector does not need changes for this server update. Keep game endpoints and source-IP allowlisting unchanged.

## Manual acceptance test

Use two separate accounts, including one stored moderator account. In the same Local Room, try `/me waves`, `/roll6`, `/roll12`, `/roll100`; check the action formatting and one shared roll result in both clients. Try one Global roll and one Private roll, then ensure a third observer does not receive the private result.

Have an ordinary account try `/givegold OtherName 100`; it should report denied without changing any balance. As moderator, grant 2,500 to the other character. Check confirmation/recipient notice, then close and sign in again as the recipient to check the gold HUD. Restart the server and verify persistence. Do not test unimplemented spending endpoints as part of this test.

## Evidence and limits

Radare2: nodejs.F at 0x1806aff80 sends event 22 (the actual immediate bytes are ba16000000, despite a misleading relocation label). Request modes 0/1/2 map to 100/6/12 sides; mode 4 supplies rollTo. Request fields are mode/send/replyMessageID and optional for/rollTo. ServiceMessages.F at 0x180e5a140 recognizes type='roll' and calls rollDice.ProcessEvent at 0x180712850, which reads id/name/mode/send/result/messageID/replyMessageID and optional rollTo. Native mode and scope field types are Int32, identity/reply fields String.

NewChatManager.EncryptBytesProtected's recovered VM at position 8368 calls EncryptBytes with static H/B. The initializer derives these using SHA256(UTF8(fixed client seed)), a 32-byte AES key and IV from hash bytes 16..31. Native AES defaults use CBC/PKCS7 and the wire carries Base64. The implementation decodes commands in memory and re-encodes generated private notices, preserving ordinary chat ciphertext. Independent .NET AES fixtures match the Node codec. This static client key is protocol compatibility, not transport security.

Synthetic checks pass: native dice layout, result ranges, room/global/private isolation, spoof rejection, encrypted /me payload preservation, native encrypted gold command parsing, role checks, bounds/overflow/cooldown, account-wide persistence and authenticated getmoney. Existing account, Discord, room/private/global chat, moderation and VM tests also pass. Visual `/me` formatting and native dice/gold HUD acceptance still require the manual test; these static/synthetic results do not prove those UI checks.
