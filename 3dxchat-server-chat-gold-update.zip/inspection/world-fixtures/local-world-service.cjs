const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const codec=require('./world-download-codec.cjs');
function validRadioUrl(value){
 if(value==='')return true;
 if(typeof value!=='string'||value.length>2048||/[\x00-\x20\x7f]/.test(value))return false;
 try{return ['http:','https:'].includes(new URL(value).protocol);}catch{return false;}
}
function createService({owner,zip,radioUrl='',onRadioChange=()=>{},log=()=>{}}){
 if(!owner||!Buffer.isBuffer(zip))throw Error('Explicit owner and ZIP are required');
 if(!validRadioUrl(radioUrl))throw Error('Radio URL must be empty or an HTTP(S) URL');
 const encrypted=codec.encrypt(zip,owner);
 const locator=crypto.createHash('sha256').update(encrypted).digest('hex').slice(0,32);
 const downloadPath=`/worlds/${locator.slice(0,2)}/${locator.slice(2,4)}/${locator}.class`;
 const server=http.createServer(async(req,res)=>{
  // Do not log request headers, bearer tokens, owner IDs, or form bodies.
  const pathname=new URL(req.url,'http://127.0.0.1').pathname;
  function send(status,body,type='text/plain; charset=utf-8'){
   res.writeHead(status,{'Content-Type':type,'Content-Length':Buffer.byteLength(body),'Cache-Control':'no-store','Connection':'close'});res.end(body);
   log({at:new Date().toISOString(),method:req.method,path:pathname,status,bytes:Buffer.byteLength(body)});
  }
  if(req.method==='GET'&&pathname==='/health')return send(200,'local-world-fixture');
  if(req.method==='GET'&&pathname===downloadPath)return send(200,encrypted,'application/octet-stream');
  if(req.method==='POST'&&['/getworld','/getradio','/setradio'].includes(pathname)){
   let length=0;const parts=[];
   try{for await(const part of req){length+=part.length;if(length>8192){send(413,'Request too large');return;}parts.push(part);}}
   catch{return;}
   const contentType=(req.headers['content-type']||'').split(';')[0].trim().toLowerCase();
   if(contentType!=='application/x-www-form-urlencoded')return send(415,'Expected URL-encoded form');
   const form=new URLSearchParams(Buffer.concat(parts).toString('utf8'));
   if(form.getAll('uid').length!==1)return send(400,'Exactly one uid is required');
   if(form.get('uid')!==owner)return pathname==='/getradio'?send(200,'error'):send(404,'No fixture for requested owner');
   if(pathname==='/getradio')return send(200,radioUrl);
   if(pathname==='/setradio'){
    if(form.getAll('url').length!==1||!validRadioUrl(form.get('url')))return send(400,'Invalid radio URL');
    const next=form.get('url');
    try{onRadioChange(next);}catch{return send(500,'Radio storage failed');}
    radioUrl=next;return send(204,'');
   }
   return send(200,locator);
  }
  // An empty acknowledgement permits testing this callback, but performs no room membership.
  if(req.method==='POST'&&pathname==='/joinroom')return send(204,'');
  return send(404,'Unsupported fixture endpoint');
 });
 return {server,locator,downloadPath,encrypted};
}
module.exports={createService,validRadioUrl};
if(require.main===module){
 const args=process.argv.slice(2),port=Number(args[0]||18743);
 if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Invalid local port');
 const owner=fs.readFileSync(path.join(__dirname,'current-download.owner.txt'),'utf8');
 const zip=fs.readFileSync(path.join(__dirname,'test-world.zip'));
 const logFile=path.join(__dirname,'local-world-service.requests.jsonl');
 const radioFile=path.join(__dirname,'local-radio.json');
 const radioUrl=fs.existsSync(radioFile)?JSON.parse(fs.readFileSync(radioFile,'utf8')).url:'';
 const fixture=createService({owner,zip,radioUrl,onRadioChange:url=>{
  fs.writeFileSync(radioFile+'.tmp',JSON.stringify({url},null,2));fs.renameSync(radioFile+'.tmp',radioFile);
 },log:r=>fs.appendFileSync(logFile,JSON.stringify(r)+'\n')});
 fixture.server.listen(port,'127.0.0.1',()=>console.log(JSON.stringify({listening:`http://127.0.0.1:${port}/`,worldPrefix:`http://127.0.0.1:${port}/worlds`,downloadPath:fixture.downloadPath,encryptedBytes:fixture.encrypted.length,authenticationImplemented:false,roomMembershipImplemented:false})));
 fixture.server.on('error',error=>{console.error(error.message);process.exitCode=1;});
 for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>fixture.server.close());
}
