const fs=require('fs'),crypto=require('crypto'),path=require('path');
const constants=JSON.parse(fs.readFileSync(path.join(__dirname,'../startup/world-cipher-constants.json')));
const suffix=Buffer.from(constants.find(c=>c.fieldRef===1456).hex,'hex');
const salt=Buffer.from(constants.find(c=>c.fieldRef===3).hex,'hex');
function derive(owner){
 if(typeof owner!=='string'||owner.length===0)throw Error('An explicit nonempty owner ID is required');
 const md5=crypto.createHash('md5').update(Buffer.concat([Buffer.from(owner,'utf8'),suffix])).digest();
 const password=crypto.createHash('sha256').update(md5).digest();
 const derived=crypto.pbkdf2Sync(password,salt,1000,48,'sha1');
 return {key:derived.subarray(0,32),iv:derived.subarray(32,48)};
}
function transform(bytes,owner,decrypt=false){
 const {key,iv}=derive(owner);
 const cipher=(decrypt?crypto.createDecipheriv:crypto.createCipheriv)('aes-256-cbc',key,iv);
 return Buffer.concat([cipher.update(bytes),cipher.final()]);
}
module.exports={derive,encrypt:(b,o)=>transform(b,o),decrypt:(b,o)=>transform(b,o,true)};
if(require.main===module){
 const [mode,owner,input,output]=process.argv.slice(2);
 if(!['encrypt','decrypt'].includes(mode)||!owner||!input||!output)throw Error('Usage: node world-download-codec.cjs encrypt|decrypt owner-id input output');
 fs.writeFileSync(output,module.exports[mode](fs.readFileSync(input),owner),{flag:'wx'});
 console.log(`${mode}: ${output}`);
}
