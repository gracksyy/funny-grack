const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
function createGoldStore({file,accounts,log=()=>{}}){
 if(!file||!accounts)throw Error('Persistent gold store requires accounts');
 let state={version:1,balances:{},grants:[]};
 function validate(s){
  const ids=new Set(accounts.list().map(a=>a.id));
  if(s?.version!==1||!s.balances||typeof s.balances!=='object'||Array.isArray(s.balances)||!Array.isArray(s.grants)||s.grants.length>1000)throw Error('Invalid gold state');
  for(const [id,n]of Object.entries(s.balances))if(!ids.has(id)||!Number.isInteger(n)||n<0||n>2147483647)throw Error('Invalid gold balance');
  for(const g of s.grants)if(!ids.has(g.actorAccount)||!ids.has(g.targetAccount)||typeof g.id!=='string'||!Number.isInteger(g.amount)||g.amount<1||g.amount>1000000||!Number.isInteger(g.before)||!Number.isInteger(g.after)||g.after!==g.before+g.amount||g.after>2147483647)throw Error('Invalid gold grant');
 }
 if(fs.existsSync(file)){state=JSON.parse(fs.readFileSync(file,'utf8'));validate(state);}
 function commit(next){validate(next);fs.mkdirSync(path.dirname(file),{recursive:true});const temp=file+'.'+crypto.randomBytes(8).toString('hex')+'.tmp';try{fs.writeFileSync(temp,JSON.stringify(next,null,2)+'\n',{flag:'wx',mode:0o600});fs.renameSync(temp,file);}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}state=next;}
 return {
  balance(token){const id=accounts.accountIdForToken(token);return id?state.balances[id]||0:null;},
  grant(token,actor,target,amount){
   if(!accounts.isModerator(token,actor))throw Error('Moderator permission required');
   const actorAccount=accounts.accountIdForToken(token),targetAccount=accounts.accountIdForCharacter(target);
   if(!targetAccount||!Number.isInteger(amount)||amount<1||amount>1000000)throw Error('Invalid target or amount (1-1000000)');
   const before=state.balances[targetAccount]||0,after=before+amount;if(after>2147483647)throw Error('Balance limit reached');
   const grant={id:crypto.randomUUID(),at:new Date().toISOString(),actorAccount,actorCharacter:actor,targetAccount,targetCharacter:target,amount,before,after};
   commit({version:1,balances:{...state.balances,[targetAccount]:after},grants:[...state.grants,grant].slice(-1000)});log({event:'gold-granted',...grant});return grant;
  }
 };
}
module.exports={createGoldStore};
