const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const defaults=()=>({age:'18',interest:'',location:'',about:''});
function normalize(value){
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!['age','interest','location','about'].includes(k)))throw Error('Invalid profile');
 const age=String(value.age);if(!/^\d{2,3}$/.test(age)||Number(age)<18||Number(age)>100)throw Error('Invalid profile age');
 if(!['','?','Men','Women','Men & Women'].includes(value.interest))throw Error('Invalid profile interest');
 for(const [key,max] of [['location',256],['about',16000]])if(typeof value[key]!=='string'||Buffer.byteLength(value[key],'utf8')>max||/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(value[key]))throw Error('Invalid profile text');
 return {age:String(Number(age)),interest:value.interest,location:value.location,about:value.about};
}
function createProfileStore({file,characters}={}){
 if(typeof characters!=='function')throw Error('Character provider required');
 let state={version:1,profiles:{}};
 const character=id=>characters().find(c=>c.id===id);
 function validate(s){if(s?.version!==1||!s.profiles||typeof s.profiles!=='object'||Array.isArray(s.profiles)||Object.keys(s.profiles).length>64)throw Error('Invalid profile store');for(const [id,value] of Object.entries(s.profiles)){if(!character(id))throw Error('Unknown local profile');normalize(value);}}
 if(file&&fs.existsSync(file)){state=JSON.parse(fs.readFileSync(file,'utf8'));validate(state);}
 return {
  get(id){const c=character(id);if(!c)return null;return {profile:JSON.stringify(state.profiles[id]||defaults()),sex:c.sex,gifts:0,married:{id:'0'},photoSlots:{},ava:0,photos:0};},
  save(id,input){
   if(!character(id)||typeof input!=='string'||Buffer.byteLength(input,'utf8')>20000)return false;
   let value;try{value=normalize(JSON.parse(input));}catch{return false;}
   const next={version:1,profiles:{...state.profiles,[id]:value}};validate(next);
   if(file){fs.mkdirSync(path.dirname(file),{recursive:true});const temp=file+'.'+crypto.randomBytes(8).toString('hex')+'.tmp';try{fs.writeFileSync(temp,JSON.stringify(next,null,2)+'\n',{flag:'wx'});fs.renameSync(temp,file);}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}}
   state=next;return true;
  }
 };
}
module.exports={createProfileStore};
