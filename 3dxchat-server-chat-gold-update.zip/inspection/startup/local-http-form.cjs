// Bounded text-only forms for the recovered character routes. The caller caps
// the complete body at 1 MiB. Files, duplicate fields and malformed parts fail.
function parseForm(body, contentType = '') {
  const type = contentType.split(';')[0].trim().toLowerCase();
  const result = new Map();
  const add = (name, value) => {
    if (result.has(name) || !/^[a-zA-Z][a-zA-Z0-9_]*$/.test(name)) throw new Error('Invalid form field');
    result.set(name, value);
  };
  if (!type || type === 'application/x-www-form-urlencoded') {
    for (const [name,value] of new URLSearchParams(body.toString('utf8'))) add(name,value);
    return result;
  }
  if (type !== 'multipart/form-data') throw new Error('Unsupported form encoding');
  const match = contentType.match(/(?:^|;)\s*boundary=(?:"([^"\r\n]+)"|([^;\s]+))/i);
  const boundary = match?.[1] ?? match?.[2];
  if (!boundary || boundary.length > 70 || /[^\x20-\x7e]/.test(boundary)) throw new Error('Invalid multipart boundary');
  const text = body.toString('utf8'), marker = `--${boundary}`;
  if (!text.startsWith(marker+'\r\n')) throw new Error('Invalid multipart body');
  let position = marker.length+2;
  for (;;) {
    const headersEnd = text.indexOf('\r\n\r\n', position);
    if (headersEnd < position || headersEnd-position > 8192) throw new Error('Invalid multipart headers');
    const headers = text.slice(position,headersEnd).split('\r\n');
    const disposition = headers.filter(h=>/^content-disposition:/i.test(h));
    if (disposition.length !== 1 || /;\s*filename\*?=/i.test(disposition[0])) throw new Error('Expected text form field');
    const field = disposition[0].match(/^content-disposition:\s*form-data;\s*name="([A-Za-z][A-Za-z0-9_]*)"\s*$/i);
    if (!field) throw new Error('Invalid field disposition');
    const end = text.indexOf('\r\n'+marker, headersEnd+4);
    if (end < 0) throw new Error('Missing multipart terminator');
    add(field[1],text.slice(headersEnd+4,end));
    position = end+2+marker.length;
    if (text.slice(position,position+2) === '--') {
      if (!['','\r\n'].includes(text.slice(position+2))) throw new Error('Unexpected multipart suffix');
      return result;
    }
    if (text.slice(position,position+2) !== '\r\n') throw new Error('Invalid multipart separator');
    position += 2;
  }
}
module.exports = {parseForm};
