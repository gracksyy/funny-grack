// Current-client solo action senders; partner/prop commands remain separate.
function readAnimationMessage(code,body,character){
  if(code!==8||body?.tag!==11||typeof body.value!=='string')return null;
  const parts=body.value.split('|'),command=parts[0];
  if(command==='~action2/SetUserVar'){
    if(parts[1]!=='mode'||parts[2]!=='walk')return null;
    if(parts.length!==4||parts[3]!=='')throw Error('Invalid animation mode');
    return {text:body.value,kind:'stop-mode'};
  }
  const kinds={'~action/rundance':'dance','~action/runEmoAction':'emote','~action/runSingleAction':'single'};
  if(!Object.hasOwn(kinds,command))return null;
  if(parts.length!==3||parts[2]!==character.name)throw Error('Invalid animation identity');
  const action=parts[1];
  if(command==='~action/rundance'){
    if(!/^-?\d{1,10}$/.test(action)||!Number.isSafeInteger(Number(action))||Number(action)<-2147483648||Number(action)>2147483647)throw Error('Invalid dance index');
  }else if(!action||action.length>256||/[\x00-\x1f\x7f]/.test(action))throw Error('Invalid animation key');
  return {text:body.value,kind:kinds[command]};
}
module.exports={readAnimationMessage};
