const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
function createFriendStore({file,characters}={}){
 if(typeof characters!=='function')throw Error('Character provider required');
 let state={version:1,links:[],requests:[]};
 const key=(a,b)=>[a,b].sort().join(':');
 const valid=id=>typeof id==='string'&&characters().some(c=>c.id===id);
 function validate(s){
  if(s?.version!==1||!Array.isArray(s.links)||!Array.isArray(s.requests)||s.links.length>256||s.requests.length>256)throw Error('Invalid friend store');
  const pairs=new Set();for(const pair of s.links){if(!Array.isArray(pair)||pair.length!==2||!pair.every(valid)||pair[0]===pair[1]||pairs.has(key(...pair)))throw Error('Invalid friend link');pairs.add(key(...pair));}
  const pending=new Set();for(const r of s.requests){const k=key(r.from,r.to);if(!valid(r.from)||!valid(r.to)||r.from===r.to||!Number.isFinite(r.createdAt)||pairs.has(k)||pending.has(k))throw Error('Invalid friend request');pending.add(k);}
 }
 if(file&&fs.existsSync(file)){state=JSON.parse(fs.readFileSync(file,'utf8'));validate(state);}
 function commit(next){
  validate(next);
  if(file){fs.mkdirSync(path.dirname(file),{recursive:true});const temp=file+'.'+crypto.randomBytes(8).toString('hex')+'.tmp';try{fs.writeFileSync(temp,JSON.stringify(next,null,2)+'\n',{flag:'wx'});fs.renameSync(temp,file);}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}}
  state=next;
 }
 const linked=(a,b)=>state.links.some(p=>key(...p)===key(a,b));
 return {linked,
  list(uid){if(!valid(uid))return null;return state.links.filter(p=>p.includes(uid)).map(p=>characters().find(c=>c.id===p.find(id=>id!==uid))).map(c=>({id:c.id,n:c.name,s:c.sex}));},
  pending(uid){return state.requests.filter(r=>r.to===uid&&Date.now()-r.createdAt<86400000).map(r=>({...r}));},
  request(from,to){
   if(!valid(from)||!valid(to)||from===to)return {kind:'invalid'};
   if(linked(from,to))return {kind:'already'};
   const requests=state.requests.filter(r=>Date.now()-r.createdAt<86400000),prior=requests.find(r=>key(r.from,r.to)===key(from,to));
   if(prior?.from===from)return {kind:'pending'};
   if(prior){commit({...state,requests:requests.filter(r=>r!==prior),links:[...state.links,[from,to].sort()]});return {kind:'accepted',requester:to};}
   commit({...state,requests:[...requests,{from,to,createdAt:Date.now()}]});return {kind:'requested'};
  },
  remove(from,to){if(!valid(from)||!valid(to)||from===to)return false;const existed=linked(from,to);commit({...state,links:state.links.filter(p=>key(...p)!==key(from,to)),requests:state.requests.filter(r=>key(r.from,r.to)!==key(from,to))});return existed;}
 };
}
module.exports={createFriendStore};
