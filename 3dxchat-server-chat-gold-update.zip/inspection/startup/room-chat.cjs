const crypto=require('node:crypto');
function readRoomChat(code,body){
 if(code!==10)return null;
 let data,reply='';
 if(body?.tag===11)data=body.value;
 else if(body?.tag===201&&Array.isArray(body.value)){
  const fields=new Map(body.value),text=fields.get('data'),parent=fields.get('replyMessageID');
  if(fields.size!==2||body.value.length!==2||text?.tag!==11||!parent||![1,11].includes(parent.tag))throw Error('shape');
  data=text.value;reply=parent.tag===11?parent.value:'';
 }else throw Error('shape');
 if(typeof data!=='string'||!data.trim()||Buffer.byteLength(data,'utf8')>4096||/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(data))throw Error('text');
 if(/^\s*~(?:action2?\/|ask\/)/.test(data))throw Error('reserved');
 if(typeof reply!=='string'||reply.length>128||/[\x00-\x1f\x7f]/.test(reply))throw Error('reply');
 return {text:data,reply};
}
function readChatMessage(code,body){
 if(code===10)return {...readRoomChat(code,body),channel:'room'};
 if(code===11)return {...readRoomChat(10,body),channel:'global'};
 if(code!==9)return null;
 if(body?.tag!==201||!Array.isArray(body.value))throw Error('shape');
 const fields=new Map(body.value),target=fields.get('for');
 if(fields.size!==body.value.length||![2,3].includes(fields.size)||target?.tag!==7||!Number.isInteger(target.value)||target.value<1||target.value>2147483647)throw Error('target');
 if(!fields.has('data')||[...fields.keys()].some(k=>!['for','data','replyMessageID'].includes(k)))throw Error('shape');
 const normalized={tag:201,value:[['data',fields.get('data')],['replyMessageID',fields.get('replyMessageID')||{tag:11,value:''}]]};
 return {...readRoomChat(10,normalized),channel:'private',recipient:String(target.value)};
}
function createRoomChat(){
 const ids=new Map();
 return {prepare(message,sender,scope=null){
  if(scope===null){if(!sender.room)return null;scope=JSON.stringify(['room',sender.room]);}
  const parent=message.reply&&message.reply!=='-1'?ids.get(message.reply):null;
  if(message.reply&&message.reply!=='-1'&&(!parent||parent!==scope))return null;
  const id=crypto.randomUUID();ids.set(id,scope);
  if(ids.size>256)ids.delete(ids.keys().next().value);
  const string=value=>({tag:11,value});
  return {tag:201,value:Object.entries({id:string(sender.uid),name:string(sender.character.name),data:string(message.text),messageID:string(id),replyMessageID:string(parent?message.reply:'')})};
 }};
}
module.exports={readRoomChat,readChatMessage,createRoomChat};
