// clotheSlot.Click and clothesPanel.PutOnAll/TakeOffAll send event 8.
// An empty final field selects the envelope sender; a nonempty field names
// the selected character. Permission for that target is checked by the server.
function readClothingMessage(code,body){
 if(code!==8||body?.tag!==11||typeof body.value!=='string')return null;
 const p=body.value.split('|');if(p[0]!=='~action2/switchwear2')return null;
 if(p.length!==4||!p[1]||p[1].length>256||/[\x00-\x1f\x7f]/.test(p[1])||!['True','False'].includes(p[2])||p[3].length>64||/[\x00-\x1f\x7f]/.test(p[3]))throw Error('Invalid clothing action');
 return {text:body.value,targetName:p[3]};
}
module.exports={readClothingMessage};
