// Current-build static transport format, recovered with radare2.
// Input must be one direction of an ordered, reassembled TCP byte stream.
const fs = require('fs');
class FrameReader {
  constructor(maxPayload = 0xffffff) {
    if (!Number.isInteger(maxPayload) || maxPayload < 0 || maxPayload > 0xffffff) throw Error('Invalid payload limit');
    this.maxPayload = maxPayload;
    this.pending = Buffer.alloc(0);
  }
  push(chunk) {
    this.pending = Buffer.concat([this.pending, chunk]);
    const frames = [];
    let offset = 0;
    while (this.pending.length - offset >= 4) {
      const length = this.pending.readUIntLE(offset, 3);
      if (length > this.maxPayload) throw Error('Payload exceeds configured limit');
      if (this.pending.length - offset < length + 4) break;
      frames.push({ type: this.pending[offset + 3], payload: Buffer.from(this.pending.subarray(offset + 4, offset + 4 + length)) });
      offset += length + 4;
    }
    this.pending = Buffer.from(this.pending.subarray(offset));
    return frames;
  }
  finish() {
    if (this.pending.length) throw Error(`Incomplete stream: ${this.pending.length} trailing bytes`);
  }
}
function encodeFrame(type, payload) {
  if (!Number.isInteger(type) || type < 0 || type > 255) throw Error('Invalid transport type');
  if (!Buffer.isBuffer(payload) || payload.length > 0xffffff) throw Error('Invalid payload');
  const header = Buffer.alloc(4);
  header.writeUIntLE(payload.length, 0, 3);
  header[3] = type;
  return Buffer.concat([header, payload]);
}
function describe(frame) {
  const result = { transportType: `0x${frame.type.toString(16).padStart(2, '0')}`, payloadBytes: frame.payload.length };
  if (frame.type === 0x81 || frame.type === 0x82) {
    result.control = frame.type === 0x81 ? 'ping request' : 'ping response';
  } else if (frame.payload.length) {
    result.objectTagCandidate = frame.payload[0];
    if (frame.payload[0] === 19 && frame.payload.length >= 3) {
      result.objectTypeCandidate = 'NodeServerEvent';
      result.eventCodeCandidate = frame.payload.readUInt16LE(1);
      if (frame.payload.length >= 4) result.bodyTagCandidate = frame.payload[3];
    }
  }
  // Deliberately omit payload bytes: captures may contain authentication tokens.
  return result;
}
module.exports = { FrameReader, encodeFrame, describe };
if (require.main === module) {
  if (!process.argv[2]) throw Error('Usage: node tcp-framing.cjs <reassembled-one-direction-stream.bin>');
  const reader = new FrameReader();
  const frames = reader.push(fs.readFileSync(process.argv[2]));
  reader.finish();
  console.log(JSON.stringify(frames.map(describe), null, 2));
}
