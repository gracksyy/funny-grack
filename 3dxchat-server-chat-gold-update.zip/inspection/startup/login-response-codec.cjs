const crypto = require('node:crypto');

// Recovered from the current Oq.F VM routine, offsets 72, 544 and 762.
const AES_KEY = 'OP7E+hX7R?NQoA+KE+u-.lr!4y7L:wKp';
const XOR_KEYS = ['w3fLsKtwsZf4#Cen%!xiZe:^QFc?lg-7', 'cT?W`,@VfdcZ5zgi0?+QoP&4F&8$2R5b'];

function xorChars(text, key) {
  let result = '';
  // C# String.get_Chars / conv.u2: operate on UTF-16 code units, not code points.
  for (let i = 0; i < text.length; i++)
    result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  return result;
}

function ivBytes(key) {
  if (typeof key !== 'string') throw new TypeError('Envelope key must be a string');
  const iv = Buffer.from(key, 'utf8');
  if (iv.length !== 16) throw new Error('Envelope key must encode to a 16-byte IV');
  return iv;
}

function decodeLoginResponse({key, data}) {
  const iv = ivBytes(key);
  if (typeof data !== 'string') throw new TypeError('Envelope data must be Base64 text');
  const compact = data.replace(/[\t\n\r ]/g, '');
  if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(compact))
    throw new Error('Invalid Base64 response');
  const encrypted = Buffer.from(compact, 'base64');
  if (!encrypted.length || encrypted.length % 16) throw new Error('Invalid AES block length');
  const cipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(AES_KEY, 'utf8'), iv);
  let text = Buffer.concat([cipher.update(encrypted), cipher.final()]).toString('utf8');
  for (const key of XOR_KEYS) text = xorChars(text, key);
  return text;
}

function encodeLoginResponse(text, key = crypto.randomBytes(8).toString('hex')) {
  if (typeof text !== 'string') throw new TypeError('Response plaintext must be a string');
  const iv = ivBytes(key);
  let transformed = text;
  for (const xorKey of [...XOR_KEYS].reverse()) transformed = xorChars(transformed, xorKey);
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(AES_KEY, 'utf8'), iv);
  return {key, data: Buffer.concat([cipher.update(Buffer.from(transformed, 'utf8')), cipher.final()]).toString('base64')};
}

module.exports = {encodeLoginResponse, decodeLoginResponse};
