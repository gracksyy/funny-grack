// Metadata only: never return message bodies, names, variable values, or
// arbitrary command identifiers supplied by a client.
const known=new Set([
 '~action2/SetUserVar','~action2/updateGhost','~action2/wetDryReq',
 '~action2/switchAscr','~action2/switchAscrList','~action2/runMoan',
 '~action/updateSexSpeed','~action/needAnimSync','~action/animAction',
 '~action/setPlayerAnimation','~action/setPlayerOldAnimation',
 '~action/setPlayerMode','~action/setMoveMode','~action/setPropUse',
 '~action/runPropPose','~action/runPropPoseOthers','~action/changepose',
 '~action/agreepose','~action/standpose','~action/SetAnimation',
 '~action/useSexPose','~action/switchSexPose','~action2/syncPartner'
]);
function ignoredActionShape(code,body){
 let value;
 if(code===7&&body?.tag===201&&Array.isArray(body.value))value=new Map(body.value).get('data');
 else if(code===8)value=body;
 if(value?.tag!==11||typeof value.value!=='string')return null;
 const p=value.value.split('|'),command=p[0];
 const family=command.startsWith('~action2/')?'action2':command.startsWith('~action/')?'action':command.startsWith('~ask/')?'ask':null;
 if(!family)return null;
 return {family,command:known.has(command)?command:'other',fields:p.length,
  emptyFields:p.flatMap((s,i)=>s===''?[i]:[]),
  numericFields:p.flatMap((s,i)=>s.length<=64&&/^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:[eE][+-]?\d+)?$/.test(s)&&Number.isFinite(Number(s.replace(',','.')))?[i]:[])};
}
module.exports={ignoredActionShape};
