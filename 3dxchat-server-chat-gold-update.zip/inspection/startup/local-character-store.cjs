const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {buildProfile} = require('./local-login-profile.cjs');

// Fixture policy, not a recovered production name rule or ID allocation scheme.
const FIRST_ID = 1000000000;
function checkName(name, characters) {
  if (typeof name !== 'string' || name.length < 3 || name.length > 20) return 'name_len';
  if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(name)) return 'bad_name';
  if (characters.some(c => c.name.toLowerCase() === name.toLowerCase())) return 'taken_name';
  return 'ok';
}

function createCharacterStore({file, defaultAvatars,maxCharacters=3} = {}) {
  if(!Number.isInteger(maxCharacters)||maxCharacters<1||maxCharacters>128)throw new Error('Invalid character capacity');
  let state = {version:1, nextId:FIRST_ID, characters:[]};
  function validate(value) {
    if (!value || value.version !== 1 || !Number.isSafeInteger(value.nextId) || value.nextId < FIRST_ID || value.nextId > 0xffffffff)
      throw new Error('Invalid local character store');
    if(!Array.isArray(value.characters)||value.characters.length>maxCharacters)throw new Error('Invalid character capacity');
    for(let i=0;i<value.characters.length;i+=3)buildProfile({token:'offline.local.validation', characters:value.characters.slice(i,i+3)});
    const prior = [];
    for (const c of value.characters) {
      if (!/^\d+$/.test(c.id) || Number(c.id) < FIRST_ID || Number(c.id) >= value.nextId || !['m','f'].includes(c.sex) || checkName(c.name, prior) !== 'ok')
          throw new Error('Invalid persisted local character');
      if(c.accountId!==undefined&&(typeof c.accountId!=='string'||! /^[A-Za-z0-9_-]{1,64}$/.test(c.accountId)))throw new Error('Invalid character account');
      prior.push(c);
    }
  }
  if (file && fs.existsSync(file)) { state = JSON.parse(fs.readFileSync(file, 'utf8')); validate(state); }
  function commit(next) {
    validate(next);
    if (file) {
      fs.mkdirSync(path.dirname(file), {recursive:true});
      const temp = `${file}.${crypto.randomBytes(8).toString('hex')}.tmp`;
      try {
        fs.writeFileSync(temp, JSON.stringify(next, null, 2)+'\n', {flag:'wx'});
        fs.renameSync(temp, file);
      } finally { if (fs.existsSync(temp)) fs.unlinkSync(temp); }
    }
    state = next; // Failed persistence must not mutate the in-memory profile.
  }
  return {
    characters:() => structuredClone(state.characters),
    checkName:name => checkName(name, state.characters),
    create(name, sex,accountId=null) {
      if(accountId!==null&&(typeof accountId!=='string'||! /^[A-Za-z0-9_-]{1,64}$/.test(accountId)))throw new Error('Invalid character account');
      const status = checkName(name, state.characters);
      if (status !== 'ok') return {error:status};
      if (!['m','f'].includes(sex)) return {error:'bad_sex'};
      if (state.characters.length >= maxCharacters || state.nextId >= 0x7fffffff) return {error:'slots_full'};
      if (!defaultAvatars?.[sex]) throw new Error('Default appearance unavailable');
      const character = {id:String(state.nextId), name, sex, data:defaultAvatars[sex], nick:'', cachekey:'',...(accountId?{accountId}:{})};
      commit({...state, nextId:state.nextId+1, characters:[...state.characters, character]});
      return {id:character.id};
    },
    save(id, data, cachekey) {
      const index = state.characters.findIndex(c => c.id === id);
      if (index < 0 || typeof data !== 'string' || !data || data.length > 750000 || /[\r\n\0]/.test(data) || data.trim() !== data ||
          typeof cachekey !== 'string' || !cachekey || cachekey.length > 256 || /[\r\n\0]/.test(cachekey) || cachekey.trim() !== cachekey) return false;
      const characters = structuredClone(state.characters);
      characters[index] = {...characters[index], data, cachekey};
      commit({...state, characters});
      return true;
    }
  };
}
module.exports = {createCharacterStore, checkName};
