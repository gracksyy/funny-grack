const crypto = require('node:crypto');
const {encodeLoginResponse} = require('./login-response-codec.cjs');

function lineValue(value, label, required = true) {
  if (typeof value !== 'string' || /[\r\n]/.test(value) || value.trim() !== value || (required && !value))
    throw new Error(`Invalid single-line ${label}`);
  return value;
}

function buildProfile({token, characters = [],moderator=false}) {
  lineValue(token, 'token');
  // login.F splits on '.', then unconditionally indexes the first three elements.
  if (token.split('.').length !== 3 || token.split('.').some(p => !p))
    throw new Error('Local token must have exactly three nonempty segments');
  if (!Array.isArray(characters) || characters.length > 3) throw new Error('At most three character slots');
  if(typeof moderator!=='boolean')throw new Error('Local moderator flag must be boolean');
  const lines = [`token=${token}`, 'moderator='+String(moderator)];
  const ids = new Set();
  characters.forEach((character, i) => {
    if (!character || typeof character !== 'object') throw new Error('Invalid character record');
    if (ids.has(character.id)) throw new Error('Duplicate character ID');
    ids.add(character.id);
    for (const field of ['id', 'name', 'sex', 'data', 'nick', 'cachekey']) {
      const value = character[field] ?? (['nick', 'cachekey'].includes(field) ? '' : undefined);
      lineValue(value, `character ${field}`, !['nick', 'cachekey'].includes(field));
      // ServerRespond ignores empty values; missing optional fields read as empty strings.
      if (value) lines.push(`${field}${i + 1}=${value}`);
    }
  });
  return lines.join('\n') + '\n';
}

function buildLoginResponse(profile, iv) {
  const envelope = encodeLoginResponse(buildProfile(profile), iv);
  return `answer=ok\nkey=${envelope.key}\ndata=${envelope.data}\n`;
}

function createLocalProfile(characters = []) {
  return {token:`offline.local.${crypto.randomBytes(16).toString('hex')}`, characters};
}

module.exports = {buildProfile, buildLoginResponse, createLocalProfile};
