const crypto=require('node:crypto');
const XOR_INNER='GL`ZoGGo$W-oU!,ktTVNG8DoI|MDvOs+';
const XOR_MIDDLE='Zp~hKdjk`oC|p#1=m?jykwih/$8cwInz';
const XOR_OUTER='LTR2lZ@v1mxF=vXz:FC-dFixWVFf*CT=';
const HASH_SUFFIX="mv&1QBSLIee$faK'H?5I:27cA~Z1NBvt";
const DES_KEY=Buffer.from('abcdefghijklmnop','utf8');
const AES_KEY=Buffer.from('566a633295152d6dafdd5e36fdf02eff','utf8');
function xor(value,key){let out='';for(let i=0;i<value.length;i++)out+=String.fromCharCode(value.charCodeAt(i)^key.charCodeAt(i%key.length));return out;}
function base64(value){if(typeof value!=='string'||!value.length||value.length>131072||! /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value))throw Error('Invalid login encoding');return Buffer.from(value,'base64');}
function hash(fields){return crypto.createHash('md5').update(fields.payload+fields.payload.length+fields.key1+fields.key2+HASH_SUFFIX,'utf8').digest('hex');}
function decrypt(algorithm,key,iv,bytes){const cipher=crypto.createDecipheriv(algorithm,key,iv);return Buffer.concat([cipher.update(bytes),cipher.final()]).toString('utf8');}
function decodeLoginRequest(form){
 const fields=Object.fromEntries(form instanceof Map?form:Object.entries(form||{}));
 if(fields.ver!=='4'||typeof fields.payload!=='string'||fields.payload.length>131072||! /^[a-f0-9]{32}$/.test(fields.hash||'')||![fields.key1,fields.key2].every(s=>typeof s==='string'&&/^[A-Za-z0-9]{16}$/.test(s)))throw Error('Invalid login fields');
 if(!crypto.timingSafeEqual(Buffer.from(fields.hash,'hex'),Buffer.from(hash(fields),'hex')))throw Error('Invalid login checksum');
 const aes=base64(xor(fields.payload,XOR_OUTER));
 const intermediate=decrypt('aes-256-cbc',AES_KEY,Buffer.from(fields.key2,'utf8'),aes);
 const des=base64(xor(intermediate,XOR_MIDDLE));
 const plaintext=xor(decrypt('des-ede-cbc',DES_KEY,Buffer.from(fields.key1.slice(0,8),'utf8'),des),XOR_INNER);
 const data=JSON.parse(plaintext);
 if(!data||typeof data!=='object'||Array.isArray(data)||typeof data.email!=='string'||data.email.length>254||typeof data.password!=='string'||data.password.length>128||/[\x00-\x1f\x7f]/.test(data.email+data.password))throw Error('Invalid login credentials');
 // Drop hardware IDs, device names, OS details and any old client token.
 return {email:data.email,password:data.password};
}
// Synthetic request generator for protocol tests; no live credentials are used.
function encodeLoginRequest(data,{key1=crypto.randomBytes(8).toString('hex'),key2=crypto.randomBytes(8).toString('hex')}={}){
 const enc=(algorithm,key,iv,input)=>{const cipher=crypto.createCipheriv(algorithm,key,iv);return Buffer.concat([cipher.update(Buffer.from(input,'utf8')),cipher.final()]).toString('base64');};
 const des=enc('des-ede-cbc',DES_KEY,Buffer.from(key1.slice(0,8),'utf8'),xor(JSON.stringify(data),XOR_INNER));
 const aes=enc('aes-256-cbc',AES_KEY,Buffer.from(key2,'utf8'),xor(des,XOR_MIDDLE));
 const fields={payload:xor(aes,XOR_OUTER),key1,key2,ver:'4'};fields.hash=hash(fields);return fields;
}
module.exports={decodeLoginRequest,encodeLoginRequest};
