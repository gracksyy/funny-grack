const crypto=require('node:crypto');
function readRollRequest(code,body){
 if(code!==22)return null;
 if(body?.tag!==201||!Array.isArray(body.value))throw Error('shape');
 const f=new Map(body.value);if(f.size!==body.value.length||[...f.keys()].some(k=>!['mode','send','replyMessageID','for','groupID','rollTo'].includes(k)))throw Error('shape');
 const int=k=>{const v=f.get(k);if(v?.tag!==7||!Number.isInteger(v.value))throw Error('integer');return v.value;};
 const mode=int('mode'),send=int('send');if(![0,1,2,4].includes(mode)||![0,1,2].includes(send)||f.has('groupID'))throw Error('unsupported mode or channel');
 const parent=f.get('replyMessageID');if(!parent||![1,11].includes(parent.tag)||parent.tag===11&&(parent.value.length>128||/[\x00-\x1f\x7f]/.test(parent.value)))throw Error('reply');
 const recipient=f.has('for')?int('for'):null;if((send===2&&(!recipient||recipient<1||recipient>2147483647))||(send!==2&&recipient!==null))throw Error('target');
 const sides=mode===4?int('rollTo'):[100,6,12][mode];if(sides<1||sides>1000000||(mode!==4&&f.has('rollTo')))throw Error('dice size');
 return {mode,send,sides,reply:parent.tag===1?'':parent.value,recipient:recipient===null?null:String(recipient)};
}
function rollPayload(request,sender,messageID,reply){
 const string=value=>({tag:11,value}),integer=value=>({tag:7,value});
 return {tag:201,value:Object.entries({type:string('roll'),id:string(sender.uid),name:string(sender.character.name),mode:integer(request.mode),send:integer(request.send),result:integer(crypto.randomInt(1,request.sides+1)),messageID:string(messageID),replyMessageID:string(reply),...(request.mode===4?{rollTo:integer(request.sides)}:{})})};
}
function goldCommand(text){
 if(!/^\s*\/(?:givegold|gold)(?:\s|$)/i.test(text))return null;
 const match=text.trim().match(/^\/(?:givegold|gold)\s+(?:"([^"\r\n]+)"|(\S+))\s+([1-9]\d{0,6})$/i);
 if(!match||Number(match[3])>1000000)throw Error('Use /givegold CharacterName 1000 (amount 1-1000000). Quote names containing spaces.');
 return {target:match[1]||match[2],amount:Number(match[3])};
}
module.exports={readRollRequest,rollPayload,goldCommand};
