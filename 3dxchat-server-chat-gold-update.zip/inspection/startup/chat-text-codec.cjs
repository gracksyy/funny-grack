const crypto=require('node:crypto');
// Native chat VM position 8368 uses NewChatManager.H/B; its initializer
// derives both from SHA256(UTF8(seed)), copying bytes 0..31 and 16..31.
const key=crypto.createHash('sha256').update('Ax3P52ONcSjRgHk5y2wfQvWyYFUKgFIP','utf8').digest(),iv=key.subarray(16,32);
function encodeChatText(text){const cipher=crypto.createCipheriv('aes-256-cbc',key,iv);return Buffer.concat([cipher.update(text,'utf8'),cipher.final()]).toString('base64');}
function decodeChatText(wire){
 if(typeof wire!=='string')return null;
 if(wire.length%4||! /^[A-Za-z0-9+/]+={0,2}$/.test(wire))return {text:wire,encrypted:false};
 try{const bytes=Buffer.from(wire,'base64');if(!bytes.length||bytes.length%16||bytes.toString('base64')!==wire)return {text:wire,encrypted:false};const cipher=crypto.createDecipheriv('aes-256-cbc',key,iv),plain=Buffer.concat([cipher.update(bytes),cipher.final()]);return {text:new TextDecoder('utf-8',{fatal:true}).decode(plain),encrypted:true};}catch{return {text:wire,encrypted:false};}
}
module.exports={encodeChatText,decodeChatText};
