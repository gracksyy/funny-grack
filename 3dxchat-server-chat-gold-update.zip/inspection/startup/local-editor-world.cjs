const crypto=require('node:crypto');
const {parseForm}=require('./local-http-form.cjs');
const {encrypt}=require('../world-fixtures/world-download-codec.cjs');
const {validRadioUrl}=require('../world-fixtures/local-world-service.cjs');

function createEditorWorld({zip,characterStore,token,onJoinRoom,log=()=>{},extraWorldOwners=[],avatarData=false,roles=null}){
  if(!Buffer.isBuffer(zip)||!characterStore||!token)throw Error('Explicit ZIP, local store and token required');
  if(!Array.isArray(extraWorldOwners)||extraWorldOwners.length>8||extraWorldOwners.some(id=>typeof id!=='string'||!/^\d+$/.test(id)||Number(id)>0xffffffff))throw Error('Invalid local fixture owners');
  const downloads=new Map(),worlds=new Map(),radio=new Map();
  function world(owner){
    if(!worlds.has(owner)){
      const bytes=encrypt(zip,owner),locator=crypto.createHash('sha256').update(bytes).digest('hex').slice(0,32);
      const path=`/worlds/${locator.slice(0,2)}/${locator.slice(2,4)}/${locator}.class`;
      const value={bytes,locator};worlds.set(owner,value);downloads.set(path,value);
    }
    return worlds.get(owner);
  }
  // Only routes belonging to this fixture are claimed. No proxy or outbound fetch.
  return function handler(request,response){
    const path=new URL(request.url,'http://127.0.0.1').pathname;
    if(!path.startsWith('/worlds/')&&!['/getworld','/getradio','/setradio','/getdonatelink','/joinroom',...(avatarData?['/chardata']:[])].includes(path))return false;
    const send=(status,body,type='text/plain; charset=utf-8')=>{
      response.writeHead(status,{'Content-Type':type,'Content-Length':Buffer.byteLength(body),'Cache-Control':'no-store'});response.end(body);
      log({method:request.method,path,status,bytes:Buffer.byteLength(body)});
    };
    if(path.startsWith('/worlds/')){
      request.resume();
      const value=downloads.get(path);
      if(request.method!=='GET'||!value){send(404,'');return true;}
      send(200,value.bytes,'application/octet-stream');return true;
    }
    if(request.method!=='POST'){request.resume();send(405,'');return true;}
    const actorToken=request.headers.authorization?.startsWith('Bearer ')?request.headers.authorization.slice(7):'';
    if(roles?!roles.validToken(actorToken):actorToken!==token){request.resume();send(403,'');return true;}
    let bytes=0,rejected=false;const chunks=[];
    request.on('data',chunk=>{
      bytes+=chunk.length;
      if(bytes>8192&&!rejected){rejected=true;send(413,'');}
      if(!rejected)chunks.push(chunk);
    });
    request.on('end',()=>{
      if(rejected)return;
      let form;try{form=parseForm(Buffer.concat(chunks),request.headers['content-type']);}catch{send(400,'');return;}
      const owner=form.get('uid');
      if(roles&&['/joinroom','/setradio'].includes(path)&&!roles.mayAct(actorToken,owner)){send(403,'');return;}
      const localCharacter=characterStore.characters().some(character=>character.id===owner);
      const fixtureWorld=['/getworld','/getradio','/getdonatelink'].includes(path)&&extraWorldOwners.includes(owner);
      if(!localCharacter&&!fixtureWorld){send(path==='/getradio'?200:404,path==='/getradio'?'error':'');return;}
      if(path==='/chardata'){send(200,characterStore.characters().find(character=>character.id===owner).data);return;}
      if(path==='/getworld'){send(200,world(owner).locator);return;}
      if(path==='/getradio'){send(200,radio.get(owner)||'');return;}
      // Donates.OnEnable posts uid; its callback treats "error" as no link.
      if(path==='/getdonatelink'){send(200,'error');return;}
      if(path==='/setradio'){
        const url=form.get('url');if(!validRadioUrl(url)){send(400,'');return;}
        radio.set(owner,url);send(204,'');return;
      }
      if(!form.get('room')||form.get('room').length>128||/[\x00-\x1f\x7f]/.test(form.get('room'))){send(400,'');return;}
      if(onJoinRoom){
        try{if(!onJoinRoom(owner,form.get('room'))){send(409,'');return;}}
        catch{send(503,'');return;}
      }
      send(204,'');
    });
    return true;
  };
}
module.exports={createEditorWorld};
