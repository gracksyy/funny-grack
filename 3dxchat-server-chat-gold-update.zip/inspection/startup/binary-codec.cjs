// Typed, offline codec. Use explicit tags rather than guessing JavaScript types.
const scalar = {3:['Int8',1],4:['UInt8',1],5:['Int16LE',2],6:['UInt16LE',2],7:['Int32LE',4],8:['UInt32LE',4],9:['FloatLE',4],10:['DoubleLE',8],23:['BigInt64LE',8],24:['BigUInt64LE',8]};
const widths = {12:2,13:3,14:4,15:4,16:4,18:4};
class Codec {
  constructor(options={}) {
    this.version=options.version||'current';
    if(!['old','current'].includes(this.version))throw Error('Version must be old or current');
    this.maxItems=options.maxItems??100000; this.maxDepth=options.maxDepth??64; this.maxBytes=options.maxBytes??0xffffff;
  }
  checkCount(n) {if(!Number.isInteger(n)||n<0||n>this.maxItems)throw Error('Invalid or excessive collection count');return n;}
  checkDepth(d) {if(d>this.maxDepth)throw Error('Nesting limit exceeded');}
  decode(buffer) {
    if(!Buffer.isBuffer(buffer)||buffer.length>this.maxBytes)throw Error('Invalid input size');
    this.input=buffer;this.position=0;
    const result=this.readObject(0);
    if(this.position!==buffer.length)throw Error(`Trailing bytes at ${this.position}`);
    return result;
  }
  readNum(kind,bytes) {
    if(this.position+bytes>this.input.length)throw Error(`Truncated value at ${this.position}`);
    const value=this.input['read'+kind](this.position);this.position+=bytes;return value;
  }
  byte(){return this.readNum('UInt8',1);}
  readSize(){const b=this.byte();return b<254?b:b===254?this.readNum('UInt16LE',2):this.readNum('UInt32LE',4);}
  readString(){
    const b=this.byte();if(b>=254)return null;
    const n=b===252?this.readNum('Int32LE',4):b===253?this.readNum('UInt16LE',2):b;
    if(n<0||n>this.maxBytes||this.position+n>this.input.length)throw Error('Invalid or truncated string');
    const value=this.input.toString('utf8',this.position,this.position+n);this.position+=n;return value;
  }
  readObject(depth){this.checkDepth(depth);const tag=this.byte();return {tag,value:this.readValue(tag,depth)};}
  readValue(tag,depth){
    this.checkDepth(depth);
    if(tag===0||tag===1)return null;
    if(tag===2)return this.byte()!==0;
    if(scalar[tag])return this.readNum(...scalar[tag]);
    if(tag===11)return this.readString();
    if(widths[tag])return Array.from({length:widths[tag]},()=>this.readNum('FloatLE',4));
    if(tag===17)return Array.from({length:4},()=>this.byte());
    if(tag>=19&&tag<=22){
      const named=this.version==='old'&&(tag===19||tag===21);
      const value=named?{name:this.readString()}:{code:this.readNum('UInt16LE',2)};
      if(tag>=21)value.errorCode=this.readNum('UInt16LE',2);
      value.data=this.readObject(depth+1);return value;
    }
    if(tag>=102&&tag<=124){const n=this.checkCount(this.readSize());return Array.from({length:n},()=>this.readValue(tag-100,depth+1));}
    if(tag===200||tag===201){
      const n=this.checkCount(tag===200?this.byte():this.readSize()),entries=[];
      for(let i=0;i<n;i++)entries.push([tag===200?this.byte():this.readString(),this.readObject(depth+1)]);
      return entries;
    }
    if(tag===202){const n=this.checkCount(this.readSize());return Array.from({length:n},()=>this.readObject(depth+1));}
    throw Error(`Unsupported object tag ${tag} at ${this.position-1}`);
  }
  encode(object){
    this.parts=[];this.outputBytes=0;this.writeObject(object,0);return Buffer.concat(this.parts);
  }
  emit(buffer){this.outputBytes+=buffer.length;if(this.outputBytes>this.maxBytes)throw Error('Output size limit exceeded');this.parts.push(buffer);}
  writeNum(kind,bytes,value){const b=Buffer.alloc(bytes);b['write'+kind](value,0);this.emit(b);}
  writeByte(value){this.writeNum('UInt8',1,value);}
  writeSize(n){
    this.checkCount(n);
    if(n<254)this.writeByte(n);
    else if(n<65536){this.writeByte(254);this.writeNum('UInt16LE',2,n);}
    else{this.writeByte(255);this.writeNum('UInt32LE',4,n);}
  }
  writeString(value){
    if(value===null){this.writeByte(254);return;}
    if(typeof value!=='string')throw Error('Expected string or null');
    const b=Buffer.from(value,'utf8');
    if(b.length<252)this.writeByte(b.length);
    else if(b.length<65536){this.writeByte(253);this.writeNum('UInt16LE',2,b.length);}
    else{this.writeByte(252);this.writeNum('Int32LE',4,b.length);}
    this.emit(b);
  }
  writeObject(object,depth){this.checkDepth(depth);if(!object||!Number.isInteger(object.tag))throw Error('Expected typed object');this.writeByte(object.tag);this.writeValue(object.tag,object.value,depth);}
  writeValue(tag,value,depth){
    this.checkDepth(depth);
    if(tag===0||tag===1){if(value!==null)throw Error('Null tag requires null');return;}
    if(tag===2){if(typeof value!=='boolean')throw Error('Expected boolean');this.writeByte(value?1:0);return;}
    if(scalar[tag]){this.writeNum(...scalar[tag],value);return;}
    if(tag===11){this.writeString(value);return;}
    if(widths[tag]||tag===17){
      const n=widths[tag]||4;if(!Array.isArray(value)||value.length!==n)throw Error('Incorrect component count');
      for(const component of value)this.writeNum(tag===17?'UInt8':'FloatLE',tag===17?1:4,component);return;
    }
    if(tag>=19&&tag<=22){
      if(this.version==='old'&&(tag===19||tag===21))this.writeString(value.name);
      else this.writeNum('UInt16LE',2,value.code);
      if(tag>=21)this.writeNum('UInt16LE',2,value.errorCode);
      this.writeObject(value.data,depth+1);return;
    }
    if(!Array.isArray(value))throw Error('Expected collection');
    this.checkCount(value.length);
    if(tag>=102&&tag<=124){this.writeSize(value.length);for(const item of value)this.writeValue(tag-100,item,depth+1);return;}
    if(tag===200||tag===201){
      if(tag===200){if(value.length>255)throw Error('Byte dictionary count exceeds 255');this.writeByte(value.length);}else this.writeSize(value.length);
      for(const [key,item] of value){if(tag===200)this.writeByte(key);else this.writeString(key);this.writeObject(item,depth+1);}return;
    }
    if(tag===202){this.writeSize(value.length);for(const item of value)this.writeObject(item,depth+1);return;}
    throw Error(`Unsupported object tag ${tag}`);
  }
}
module.exports={Codec};
