const crypto = require('node:crypto');
// Current helper 0x180570610 supplies these UTF-8 constants. 0x180570220
// selects CipherMode.ECB (2), PaddingMode.Zeros (3), then reads decrypted text.
const KEY = Buffer.from('abcdefg_abcdefg_abcdefg_abcdefg_', 'utf8');

function decodeLegacyAvatar(data) {
  if (typeof data !== 'string') throw new TypeError('Avatar data must be Base64 text');
  // The native helper tolerates one surplus '=' when text length mod 4 is 1.
  if (data.length % 4 === 1 && data.endsWith('=')) data = data.slice(0, -1);
  const compact = data.replace(/[\t\r\n ]/g, '');
  if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(compact)) throw new Error('Invalid avatar Base64');
  const bytes = Buffer.from(compact, 'base64');
  if (!bytes.length || bytes.length % 16) throw new Error('Invalid avatar AES block length');
  const cipher = crypto.createDecipheriv('aes-256-ecb', KEY, null);
  cipher.setAutoPadding(false);
  // PaddingMode.Zeros cannot infer the unpadded length. The subsequent native
  // cryptoEbash wrapper trims '\0' from both ends of the resulting string.
  return Buffer.concat([cipher.update(bytes), cipher.final()]).toString('utf8').replace(/^\0+|\0+$/g, '');
}

function encodeLegacyAvatar(text) {
  if (typeof text !== 'string' || text.startsWith('\0') || text.endsWith('\0')) throw new Error('Avatar text must not have edge NUL characters');
  const bytes = Buffer.from(text, 'utf8');
  const padded = Buffer.alloc(Math.ceil(bytes.length / 16) * 16);
  bytes.copy(padded);
  const cipher = crypto.createCipheriv('aes-256-ecb', KEY, null);
  cipher.setAutoPadding(false);
  return Buffer.concat([cipher.update(padded), cipher.final()]).toString('base64');
}

module.exports = {decodeLegacyAvatar, encodeLegacyAvatar};
