// Current walk.OnMouseDown and walk.Update send these through nodejs.SendRoom.
function readMovementMessage(code,body){
  if(code!==8||body?.tag!==11||typeof body.value!=='string')return null;
  const parts=body.value.split('|');
  if(parts[0]==='~action2/setMoveMode'){
    if(parts.length!==2||!['walk','run'].includes(parts[1]))throw Error('Invalid movement mode');
    return {text:body.value,kind:'mode'};
  }
  if(parts[0]!=='~action2/walk')return null;
  if(parts.length!==8||parts.at(-1)!=='')throw Error('Invalid movement shape');
  for(const field of parts.slice(1,-1)){
    if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(field)||!Number.isFinite(Number(field))||Math.abs(Number(field))>1000000)throw Error('Invalid movement coordinate');
  }
  return {text:body.value,kind:'walk'};
}
module.exports={readMovementMessage};
