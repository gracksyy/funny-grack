// Only the setup messages traced in the current client are recognized here.
function readSetupMessage(code,body,character){
  let text,recipient=null;
  if(code===7){
    if(body?.tag!==201||!Array.isArray(body.value)||body.value.length!==2)throw Error('Invalid setup PM');
    const fields=new Map(body.value);
    if(fields.size!==2||!fields.has('for')||!fields.has('data'))throw Error('Invalid setup PM');
    const target=fields.get('for');
    if(target.tag!==7||!Number.isInteger(target.value)||target.value<1||target.value>0x7fffffff)throw Error('Invalid setup recipient');
    recipient=String(target.value);text=fields.get('data');
  }else if(code===8)text=body;
  else return null;
  if(text?.tag!==11||typeof text.value!=='string'||text.value.length>65536||/[\x00-\x1f]/.test(text.value))throw Error('Invalid setup text');
  const value=text.value;
  if(code===7){
    if(value==='~action2/getCacheKey|'||value==='~action2/getPosition|')return {recipient,text:value,kind:value==='~action2/getPosition|'?'state-request':'cache-request'};
    // Current keys can be formatted timestamps containing ordinary spaces.
    if(/^~action2\/sendCacheKey\|[^|\x00-\x1f]{1,256}$/.test(value))return {recipient,text:value};
  }
  const parts=value.split('|'),command=parts[0];
  const coordinates=['~action/setPlayerPosition','~action/setPlayerTarget','~action/setPlayerRotation'];
  const state=['~action/setPlayerWear','~action/setMoveMode','~action/setPropUse','~action/setPlayerAnimation','~action/setPlayerOldAnimation','~action/setPlayerMode','~action/setPlayerPivotPosition','~action/setPlayerPivotRotation'];
  if(code===7&&state.includes(command)){
    if(parts.length<3||parts[1]!==character.name)throw Error('Invalid setup identity');
    if(['~action/setPlayerAnimation','~action/setPlayerOldAnimation'].includes(command)){
      if(parts.length!==4||parts[3]!==''||!parts[2]||parts[2].length>256)throw Error('Invalid animation snapshot');
      return {recipient,text:value,kind:command==='~action/setPlayerAnimation'?'animation-state':'old-animation-state'};
    }
    return {recipient,text:value};
  }
  if(!coordinates.includes(command))return null;
  const count=command==='~action/setPlayerRotation'?4:6;
  if(parts.length!==count||parts.at(-1)!==''||parts[1]!==character.name)throw Error('Invalid setup identity');
  for(const number of parts.slice(2,-1)){
    if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(number)||!Number.isFinite(Number(number))||Math.abs(Number(number))>1000000)throw Error('Invalid setup position');
  }
  return {recipient,text:value};
}
module.exports={readSetupMessage};
