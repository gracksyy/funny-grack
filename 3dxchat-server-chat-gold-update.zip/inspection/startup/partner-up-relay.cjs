function readPartnerUpMessage(code,body,character){
 let value,recipient=null;
 if(code===7){
  if(body?.tag!==201||!Array.isArray(body.value))return null;
  const fields=new Map(body.value),data=fields.get('data');
  if(data?.tag!==11||typeof data.value!=='string'||!/^~(?:ask\/(?:party|acceptParty)|action\/(?:delPartner|breakParty))\|/.test(data.value))return null;
  const target=fields.get('for');
  if(body.value.length!==2||fields.size!==2||target?.tag!==7||!Number.isInteger(target.value)||target.value<1||target.value>2147483647)throw Error('Invalid partner recipient');
  value=data.value;recipient=String(target.value);
 }else if(code===8&&body?.tag===11&&typeof body.value==='string')value=body.value;
 else return null;
 const p=value.split('|'),command=p[0];
 if(code===7&&['~ask/party','~ask/acceptParty'].includes(command)){
  if(p.length!==2||p[1]!==character.sex)throw Error('Invalid partner request sex');
  return {kind:command==='~ask/party'?'request':'accept',recipient,text:value};
 }
 if(code===7&&command==='~action/delPartner'){
  if(p.length!==3||p[1]!==character.name||!p[2]||p[2].length>128||/[\x00-\x1f\x7f]/.test(p[2]))throw Error('Invalid partner removal');
  return {kind:'remove',recipient,partnerName:p[2],text:value};
 }
 if(code===7&&command==='~action/breakParty'){
  if(p.length!==2||p[1]!=='')throw Error('Invalid partner break');
  return {kind:'break',recipient,text:value};
 }
 if(code===8&&command==='~action/LettingMyReq'){
  if(p.length!==3||p[1]!==character.name||!p[2]||p[2].length>256||/[\x00-\x1f\x7f]/.test(p[2]))throw Error('Invalid partner state hint');
  return {kind:'state',recipient:null,text:value};
 }
 return null;
}
function createPartnerUpState(){
 const requests=new Map(),links=new Map();
 const key=(a,b)=>[a,b].sort().join(':');
 function removeLink(a,b){links.get(a)?.delete(b);links.get(b)?.delete(a);}
 function remove(uid){
  const former=[...(links.get(uid)||[])];
  for(const other of links.get(uid)||[])removeLink(uid,other);links.delete(uid);
  for(const [k,r] of requests)if(r.from===uid||r.to===uid)requests.delete(k);
  return former;
 }
 return {remove,linked:(a,b)=>links.get(a)?.has(b)===true,route(message,sender,sessions){
  const now=Date.now();for(const [k,r] of requests)if(r.until<=now)requests.delete(k);
  if(!sender.room)return false;
  const peers=[...sessions].filter(s=>s!==sender&&s.room===sender.room&&s.socket&&!s.socket.destroyed);
  if(message.kind==='state')return peers.some(p=>links.get(sender.uid)?.has(p.uid)||[...requests.values()].some(r=>r.room===sender.room&&key(r.from,r.to)===key(sender.uid,p.uid)));
  const target=peers.find(p=>p.uid===message.recipient);if(!target)return false;
  const pair=key(sender.uid,target.uid);
  if(message.kind==='request'){
   if(links.get(sender.uid)?.has(target.uid))return false;
   requests.set(pair,{from:sender.uid,to:target.uid,room:sender.room,until:now+60000});return true;
  }
  if(message.kind==='accept'){
   const r=requests.get(pair);if(!r||r.from!==target.uid||r.to!==sender.uid||r.room!==sender.room)return false;
   // First visual test supports one partner per character; multi-partner fan-out
   // requires separate ordering and membership tests.
   if((links.get(sender.uid)?.size||0)>=1||(links.get(target.uid)?.size||0)>=1)return false;
   for(const [a,b] of [[sender.uid,target.uid],[target.uid,sender.uid]]){if(!links.has(a))links.set(a,new Set());links.get(a).add(b);}
   requests.delete(pair);return true;
  }
  if(message.kind==='remove'){
   if(!links.get(sender.uid)?.has(target.uid)||![sender.character.name,target.character.name].includes(message.partnerName))return false;
   const named=[sender,...peers].find(p=>p.character.name===message.partnerName);
   if(!named)return false;
   if(named===sender){for(const p of links.get(sender.uid)||[])removeLink(sender.uid,p);}
   else if(!links.get(sender.uid)?.has(named.uid))return false;
   else removeLink(sender.uid,named.uid);
   return true;
  }
  if(message.kind==='break'){
   if(!links.get(sender.uid)?.has(target.uid)&&!requests.has(pair))return false;
   requests.delete(pair);removeLink(sender.uid,target.uid);return true;
  }
  return false;
 }};
}
module.exports={readPartnerUpMessage,createPartnerUpState};
