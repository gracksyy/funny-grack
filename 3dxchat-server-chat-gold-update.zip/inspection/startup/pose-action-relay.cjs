const commands=new Set(['~action/askForPose','~action/acceptPoseAsk','~action/declinePose','~action/useSexPose','~action/switchSexPose','~action/stopSexPS','~action2/syncPartner','~action/updateSexSpeed','~action/needAnimSync']);
const atom=s=>typeof s==='string'&&s.length>0&&s.length<=256&&!/[\x00-\x1f\x7f|]/.test(s);
const selection=s=>s===''||atom(s);
const int=s=>/^-?\d+$/.test(s)&&Number.isSafeInteger(Number(s))&&Number(s)>=-2147483648&&Number(s)<=2147483647;
// Boxed Single.ToString and Single.Parse use the client's culture. Preserve
// the original decimal separator; normalize only for bounded numeric validation.
const speed=s=>s.length<=64&&/^\+?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:[eE][+-]?\d+)?$/.test(s)&&Number.isFinite(Math.fround(Number(s.replace(',','.'))));
function readPoseMessage(code,body,character){
 let value,recipient=null;
 if(code===7){
  if(body?.tag!==201||!Array.isArray(body.value))return null;
  const fields=new Map(body.value),data=fields.get('data');value=data?.value;
  if(data?.tag!==11||typeof value!=='string'||!commands.has(value.split('|')[0]))return null;
  const target=fields.get('for');
  if(body.value.length!==2||fields.size!==2||target?.tag!==7||!Number.isInteger(target.value)||target.value<1||target.value>2147483647)throw Error('Invalid pose recipient');
  recipient=String(target.value);
 }else if(code===8&&body?.tag===11&&typeof body.value==='string')value=body.value;
 else return null;
 const p=value.split('|'),command=p[0];if(!commands.has(command))return null;
 if(value.length>4096||/[\x00-\x1f\x7f]/.test(value))throw Error('Invalid pose message');
 const fail=()=>{const error=Error('Invalid pose shape or identity');error.poseShape={command,fields:p.length,emptyFields:p.flatMap((s,i)=>s===''?[i]:[])};throw error;};
 if(command==='~action/updateSexSpeed'){
  if(code!==7||p.length!==3||!speed(p[1])||p[2]!=='')fail();
  return {kind:'speed',recipient,text:value};
 }
 if(command==='~action/needAnimSync'){
  if(code!==7||p.length!==4||p[1]!==character.name||!selection(p[2])||p[3]!=='')fail();
  return {kind:'animation-sync',recipient,text:value};
 }
 if(command==='~action/askForPose'){
  if(code!==7||p.length!==6||!selection(p[1])||!atom(p[2])||p[3]!==character.name||!int(p[4])||p[5]!=='')fail();
  return {kind:'request',recipient,text:value,selection:[p[2],p[4],p[1]]};
 }
 if(command==='~action/acceptPoseAsk'){
  if(code!==7||p.length!==6||p[1]!==character.name||!atom(p[2])||!int(p[3])||!selection(p[4])||p[5]!=='')fail();
  return {kind:'accept',recipient,text:value,selection:p.slice(2,5)};
 }
 if(command==='~action/declinePose'){
  if(code!==7||p.length!==2||p[1]!=='')fail();return {kind:'decline',recipient,text:value};
 }
 if(command==='~action2/syncPartner'){
  if(code!==7||p.length!==4||!atom(p[1])||!['f','m'].includes(p[2])||p[3]!=='')fail();
  return {kind:'sync',recipient,text:value,subject:p[1],sex:p[2]};
 }
 if(command==='~action/stopSexPS'){
  if(code!==8||p[1]!==character.name||p.at(-1)!==''||p.length<4||p.length>5||!p.slice(2,-1).every(atom))fail();
  return {kind:'stop',recipient,text:value,names:p.slice(2,-1)};
 }
 // The participant map already ends in '|'; the enclosing concatenation adds
 // another '|'. Preserve that empty field rather than normalizing the text.
 if(code!==8||p[1]!==character.name||!int(p[2])||!int(p[3])||p.length!==9||p[6]!==''||!atom(p[7])||!selection(p[8]))fail();
 const participants=p.slice(4,6).map(s=>{const i=s.indexOf('=');if(i<1||!atom(s.slice(0,i))||!atom(s.slice(i+1)))fail();return s.slice(0,i);});
 if(new Set(participants).size!==2||!participants.includes(character.name))fail();
 return {kind:command==='~action/useSexPose'?'start':'change',recipient,text:value,names:participants};
}
function createPoseState(partnerUp){
 const requests=new Map(),active=new Map(),key=(a,b)=>[a,b].sort().join(':');
 function remove(uid){
  const ended=[];
  for(const [pair,r] of active)if(r.from===uid||r.to===uid){ended.push({pair,...r});active.delete(pair);}
  for(const [pair,r] of requests)if(r.from===uid||r.to===uid)requests.delete(pair);
  return ended;
 }
 return {remove,snapshots(viewer,sessions,ready=null){
  if(!viewer.room)return [];
  const current=[...sessions],result=[];
  for(const [pair,r] of active){
   if(!r.started||r.room!==viewer.room||!r.snapshot)continue;
   const a=current.find(s=>s.uid===r.from&&s.room===r.room),b=current.find(s=>s.uid===r.to&&s.room===r.room);
   if(!a||!b||!partnerUp.linked(a.uid,b.uid))continue;
   if(ready&&(!ready.has(a.uid)||!ready.has(b.uid)))continue;
   // updateSexSpeed resolves the receiving client's own /update object.
   // Its cached PM is useful to a returning participant, not a spectator.
   const participant=viewer.uid===r.from||viewer.uid===r.to;
   result.push({pair,messages:[r.snapshot,...(participant&&r.speed?[r.speed]:[])]});
  }
  return result;
 },route(message,sender,sessions){
  const now=Date.now();for(const [k,r] of requests)if(r.until<=now)requests.delete(k);
  const peers=[...sessions].filter(s=>s!==sender&&s.room===sender.room&&s.socket&&!s.socket.destroyed);
  if(message.kind==='animation-sync'){
   // sendPosition replies to a late observer with needAnimSync while posing.
   // It is a state reply, so its recipient need not be a member of the pair.
   if(!sender.room||!peers.some(s=>s.uid===message.recipient))return false;
   return [...active.values()].some(r=>r.started&&r.room===sender.room&&(r.from===sender.uid||r.to===sender.uid)&&partnerUp.linked(r.from,r.to));
  }
  const target=message.recipient?peers.find(s=>s.uid===message.recipient):peers.find(s=>partnerUp.linked(sender.uid,s.uid));
  if(!sender.room||!target||!partnerUp.linked(sender.uid,target.uid))return false;
  const pair=key(sender.uid,target.uid),names=[sender.character.name,target.character.name];
  if(message.names&&(!message.names.includes(target.character.name)||!message.names.every(n=>names.includes(n))))return false;
  if(message.kind==='request'){
   requests.set(pair,{from:sender.uid,to:target.uid,room:sender.room,selection:message.selection,until:now+60000});return true;
  }
  if(['accept','decline'].includes(message.kind)){
   const r=requests.get(pair);if(!r||r.from!==target.uid||r.to!==sender.uid||r.room!==sender.room)return false;
   if(message.kind==='accept'&&r.selection.some((v,i)=>v!==message.selection[i]))return false;
   requests.delete(pair);if(message.kind==='accept')active.set(pair,r);return true;
  }
  if(message.kind==='sync')return !!active.get(pair)&&[sender,target].some(s=>s.character.name===message.subject&&s.character.sex===message.sex);
  if(!active.has(pair))return false;
  if(message.kind==='speed'){
   const r=active.get(pair);if(r.started!==true)return false;
   if(message.kind==='speed')r.speed={id:sender.uid,name:sender.character.name,text:message.text};
   return true;
  }
  if(['start','change'].includes(message.kind)){
   const r=active.get(pair);r.started=true;r.snapshot={id:sender.uid,name:sender.character.name,text:message.text};
  }
  if(message.kind==='stop'){active.delete(pair);requests.delete(pair);}
  return true;
 }};
}
module.exports={readPoseMessage,createPoseState};
