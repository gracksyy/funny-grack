const net = require('node:net');
const crypto = require('node:crypto');
const {FrameReader,encodeFrame} = require('./tcp-framing.cjs');
const {Codec} = require('./binary-codec.cjs');
const {readSetupMessage}=require('./avatar-action-relay.cjs');
const {readMovementMessage}=require('./movement-action-relay.cjs');
const {readAnimationMessage}=require('./animation-action-relay.cjs');
const {readPairedDanceMessage,createPairedDanceState}=require('./paired-dance-relay.cjs');
const {readPartnerUpMessage,createPartnerUpState}=require('./partner-up-relay.cjs');
const {readPoseMessage,createPoseState}=require('./pose-action-relay.cjs');
const {ignoredActionShape}=require('./ignored-action-shape.cjs');
const {readClothingMessage}=require('./clothing-action-relay.cjs');
const {readChatMessage,createRoomChat}=require('./room-chat.cjs');
const {readRollRequest,rollPayload,goldCommand}=require('./chat-commands.cjs');
const {encodeChatText,decodeChatText}=require('./chat-text-codec.cjs');

function readAuth(object) {
  if (object.tag !== 201 || !Array.isArray(object.value) || ![2,3].includes(object.value.length)) throw new Error('Invalid Auth');
  const auth = Object.create(null);
  for (const [name,value] of object.value) {
    if (!['token','uid','resumeToken'].includes(name) || Object.hasOwn(auth,name) || value.tag !== 11 || typeof value.value !== 'string' || !value.value || value.value.length > 512)
      throw new Error('Invalid Auth field');
    auth[name] = value.value;
  }
  if (!auth.token || !auth.uid) throw new Error('Missing Auth field');
  return auth;
}

function createGameTcp({authorize,log=()=>{},resumeMs=120000,authMs=5000,idleMs=60000,maxConnections=8,disconnectOnceAfterMs=null,sharedLocations=()=>[],presence=false,characterFor=()=>null,characters=()=>[],goldStore=null,avatarRelay=false,movementRelay=false,animationRelay=false,pairedDanceRelay=false,partnerUpRelay=false,poseRelay=false,chatRelay=false,friendStore=null,moderation=null,allowRemote=()=>true}={}) {
  if (typeof authorize !== 'function') throw new Error('An explicit local authorization function is required');
  if(typeof sharedLocations!=='function')throw new Error('Explicit shared-location provider required');
  if(typeof characterFor!=='function')throw new Error('Explicit local character provider required');
  if(avatarRelay&&!presence)throw new Error('Avatar relay requires local presence');
  if(chatRelay&&!presence)throw new Error('Room chat requires local presence');
  if(friendStore&&!presence)throw new Error('Friends require local presence');
  if(movementRelay&&!avatarRelay)throw new Error('Movement relay requires avatar relay');
  if(animationRelay&&!movementRelay)throw new Error('Animation relay requires movement relay');
  if(pairedDanceRelay&&!animationRelay)throw new Error('Paired dance requires animation relay');
  if(partnerUpRelay&&!pairedDanceRelay)throw new Error('Partner Up requires paired dance relay');
  if(poseRelay&&!partnerUpRelay)throw new Error('Pose relay requires Partner Up');
  if(disconnectOnceAfterMs!==null&&(!Number.isInteger(disconnectOnceAfterMs)||disconnectOnceAfterMs<1||disconnectOnceAfterMs>120000))throw new Error('Invalid one-shot disconnect delay');
  const sockets = new Set(), sessions = new Map();
  const pairedDances=createPairedDanceState();
  const partnerUp=createPartnerUpState();
  const poses=createPoseState(partnerUp);
  const chat=createRoomChat();
  const goldCooldown=new Map();
  let disconnectPlanned=false;
  const string=value=>({tag:11,value});
  const dictionary=value=>({tag:201,value:Object.entries(value)});
  const integer=value=>({tag:7,value});
  function muteNotice(uid,time){
    const session=[...sessions.values()].find(s=>s.uid===uid);if(!session)return false;
    deliver(session,4,dictionary({type:string('mute'),mode:integer(1),time:integer(time),...(time===0?{unMute:string('true')}:{})}));
    log({event:'moderation-notice',kind:time?'mute':'unmute'});return true;
  }
  function friendNotice(uid,type,other){
    const character=characterFor(other);if(!character)return false;
    const session=[...sessions.values()].find(s=>s.uid===uid);if(!session)return false;
    deliver(session,4,dictionary({type:string(type),id:string(other),name:string(character.name),sex:string(character.sex)}));
    log({event:'friend-notice',kind:type});return true;
  }
  function deliver(session,code,data){
    if(session.socket&&!session.socket.destroyed){
      try{session.sendEvent(code,data);}catch{session.socket.destroy();}
    }else if(session.pending.length<64)session.pending.push({code,data});
    else session.expires=0;
  }
  function restorePoses(viewer,ready=null){
    if(!poseRelay||!viewer.socket||viewer.socket.destroyed)return;
    prune();
    for(const snapshot of poses.snapshots(viewer,sessions.values(),ready)){
      if(ready&&viewer.poseRestored.has(snapshot.pair))continue;
      for(const message of snapshot.messages)deliver(viewer,5,dictionary({id:string(message.id),name:string(message.name),data:string(message.text)}));
      viewer.poseRestored.add(snapshot.pair);
      log({event:'pose-restored',kind:ready?'late-join':'resume',messages:snapshot.messages.length});
    }
  }
  function announce(session,type){
    if(!presence||!session.room)return;
    const data=dictionary({type:string(type),id:string(session.uid),name:string(session.character.name),...(type==='JoinRoom'?{sex:string(session.character.sex)}:{})});
    for(const other of sessions.values())if(other!==session&&other.room===session.room){
      deliver(other,4,data);
    }
    log({event:'presence',kind:type});
  }
  function invalidatePose(uid){
    for(const other of sessions.values()){
      other.poseReady.delete(uid);
      for(const pair of other.poseRestored)if(pair.split(':').includes(uid))other.poseRestored.delete(pair);
    }
  }
  function leave(session){
    if(!session)return;
    const ended=poses.remove(session.uid),former=partnerUp.remove(session.uid);
    pairedDances.remove(session.uid);
    let stops=0,removals=0;
    if(session.room&&session.character){
      const peers=[...sessions.values()].filter(s=>s!==session&&s.room===session.room);
      // Stop while both avatars still exist, then remove the relationship,
      // and finally announce avatar departure. Detached peers queue this order.
      for(const pose of ended)if(pose.started){
        const a=[session,...peers].find(s=>s.uid===pose.from),b=[session,...peers].find(s=>s.uid===pose.to);
        if(!a||!b)continue;
        const data=dictionary({id:string(session.uid),name:string(session.character.name),data:string('~action/stopSexPS|'+session.character.name+'|'+a.character.name+'|'+b.character.name+'|')});
        for(const other of peers){deliver(other,5,data);stops++;}
      }
      for(const other of peers)if(former.includes(other.uid)){
        deliver(other,5,dictionary({id:string(session.uid),name:string(session.character.name),data:string('~action/delPartner|'+session.character.name+'|'+session.character.name)}));removals++;
      }
    }
    invalidatePose(session.uid);
    if(stops||removals)log({event:'paired-departure',stops,removals});
    announce(session,'LeaveRoom');session.room=null;session.pending=[];session.poseReady.clear();session.poseRestored.clear();
  }
  function prune() { for (const [key,session] of sessions) if(!session.socket && session.expires <= Date.now()){leave(session);sessions.delete(key);} if(moderation)for(const uid of moderation.expired())muteNotice(uid,0); }
  const expiryTimer=presence?setInterval(prune,Math.max(10,Math.min(resumeMs,1000))):null;
  expiryTimer?.unref();
  function roster(room,except){
    return [...sessions.values()].filter(s=>s!==except&&s.room===room).map(s=>dictionary({
      i:string(s.uid),n:string(s.character.name),s:string(s.character.sex),
      // Match CreatePlayers' own-character idle suffix: False, empty, 0, False.
      wetDryVar:string('False'),semenTypeVar:string(''),semenNumVar:string('0'),isRunVar:string('False'),removedAscrListVar:{tag:1,value:null}
    }));
  }
  const server = net.createServer(socket=>{
    if(!allowRemote(socket.remoteAddress)){log({event:'access-denied'});socket.destroy();return;}
    if (sockets.size >= maxConnections) {socket.destroy();return;}
    sockets.add(socket);
    socket.setNoDelay(true);socket.setTimeout(idleMs);
    const frames=new FrameReader(1024*1024), codec=new Codec({maxBytes:1024*1024,maxItems:64,maxDepth:8});
    let approved=false, uid, issued, closed=false,disconnectTimer;
    const authTimer=setTimeout(()=>{log({event:'auth-timeout'});socket.destroy();},authMs);
    function send(type,payload) {
      const wire=encodeFrame(type,payload);
      if (socket.writableLength+wire.length > 2*1024*1024) throw new Error('Output limit');
      socket.write(wire);
    }
    function event(code,data) {send(0x7f,codec.encode({tag:19,value:{code,data}}));log({event:'sent',code});}
    function fail(reason) {if(!closed){closed=true;log({event:'rejected',reason});socket.destroy();}}
    socket.on('data',chunk=>{
      if(closed)return;
      try {
        for(const frame of frames.push(chunk)) {
          log({event:'frame',type:frame.type,bytes:frame.payload.length,approved});
          if(approved&&!authorize(sessions.get(issued)?.token,uid)){
            leave(sessions.get(issued));sessions.delete(issued);fail('local-session');return;
          }
          // NetPeer echoes the full payload. Live captures include a double
          // timestamp plus extension (28 bytes), not just an eight-byte double.
          if(frame.type===0x81 || frame.type===0x82) {
            if(![8,28].includes(frame.payload.length)) throw new Error('Invalid keepalive');
            if(frame.type===0x81)send(0x82,frame.payload);
            log({event:frame.type===0x81?'ping':'pong'});continue;
          }
          if(!approved) {
            if(frame.type!==0x5f) throw new Error('Auth required');
            const auth=readAuth(codec.decode(frame.payload));
            if(!authorize(auth.token,auth.uid)) {fail('local-session');return;}
            prune();
            let resumed=false;
            let room=null;
            let pending=[];
            const character=presence?characterFor(auth.uid):null;
            if(presence&&(!character||typeof character.name!=='string'||!character.name||character.name.length>64||/[|\x00-\x1f]/.test(character.name)||!['m','f'].includes(character.sex))){fail('local-character');return;}
            if(auth.resumeToken) {
              const previous=sessions.get(auth.resumeToken);
              if(!previous || previous.uid!==auth.uid || previous.token!==auth.token || previous.socket) {fail('resume-session');return;}
              room=previous.room;pending=previous.pending;sessions.delete(auth.resumeToken);resumed=true;
            }
            if([...sessions.values()].some(session=>session.uid===auth.uid&&session.socket)){fail('active-character');return;}
            if(!resumed)for(const [key,session] of sessions)if(session.uid===auth.uid){leave(session);sessions.delete(key);}
            // Bound detached session state; only local chat-room identity is retained.
            if(sessions.size>=64) {fail('session-limit');return;}
            approved=true;uid=auth.uid;clearTimeout(authTimer);
            issued=crypto.randomBytes(24).toString('hex');
            sessions.set(issued,{uid,token:auth.token,expires:Date.now()+resumeMs,socket,room,sendEvent:event,character:character&&{name:character.name,sex:character.sex},pending:[],poseReady:new Set(),poseRestored:new Set()});
            log({event:'approved',resumed});
            if(resumed) {
              event(38,{tag:1,value:null});
              event(37,{tag:11,value:issued});
              for(const missed of pending)event(missed.code,missed.data);
              restorePoses(sessions.get(issued));
            } else {
              event(37,{tag:11,value:issued});
              event(3,{tag:1,value:null});
              if(friendStore)for(const r of friendStore.pending(uid))friendNotice(uid,'FriendRequest',r.from);
            }
            if(moderation&&moderation.remaining(uid))muteNotice(uid,moderation.remaining(uid));
            if(!resumed&&!disconnectPlanned&&disconnectOnceAfterMs!==null){
              disconnectPlanned=true;
              log({event:'test-disconnect-scheduled',delayMs:disconnectOnceAfterMs});
              disconnectTimer=setTimeout(()=>{
                if(!closed&&sessions.get(issued)?.socket===socket){
                  // Destroy only this fixture's socket. The normal close handler
                  // detaches and retains its resume record; the service stays up.
                  closed=true;log({event:'test-disconnect'});socket.destroy();
                }
              },disconnectOnceAfterMs);
            }
            continue;
          }
          if(frame.type!==0x7f) throw new Error('Unexpected transport');
          const object=codec.decode(frame.payload);
          if(![19,20,21,22].includes(object.tag)) throw new Error('Expected event');
          // Never log bodies or user/room identifiers.
          log({event:'received',code:object.value.code,tag:object.tag,bytes:frame.payload.length});
          if(moderation&&object.tag===19&&[28,34].includes(object.value.code)){
            const sender=sessions.get(issued),data=object.value.data;
            let fields;try{if(data?.tag!==201||!Array.isArray(data.value))throw Error();fields=new Map(data.value);if(fields.size!==data.value.length)throw Error();}catch{log({event:'moderation-rejected',reason:'shape'});continue;}
            if(object.value.code===28){
              const target=fields.get('userID');
              if(fields.size!==1||target?.tag!==7||!Number.isInteger(target.value)||!characterFor(String(target.value))||(String(target.value)!==uid&&!moderation.isModerator(sender.token,uid))){log({event:'moderation-rejected',reason:'permission-or-shape'});continue;}
              event(4,dictionary({type:string('muteTimer'),userID:integer(target.value),muteChatTimer:integer(moderation.remaining(String(target.value))||-1),muteReactTimer:integer(-1)}));continue;
            }
            const actor=fields.get('adminID'),targetId=fields.get('kickedUserID'),mode=fields.get('mode');
            if(!moderation.isModerator(sender.token,uid)){log({event:'moderation-rejected',reason:'permission'});continue;}
            if(fields.size!==3||actor?.tag!==11||actor.value!==uid||targetId?.tag!==11||mode?.tag!==7||mode.value!==1){log({event:'moderation-rejected',reason:'shape-or-mode'});continue;}
            const target=[...sessions.values()].find(s=>s.uid===targetId.value&&s!==sender&&s.socket&&!s.socket.destroyed&&sender.room&&s.room===sender.room);
            if(!target){log({event:'moderation-rejected',reason:'target-room'});continue;}
            deliver(target,4,string('KickedFromRoom'));leave(target);
            log({event:'moderation-action',kind:'room-kick'});continue;
          }
          if(friendStore&&object.tag===19&&object.value.code===7&&object.value.data?.tag===201){
            const body=object.value.data,fields=new Map(body.value),value=fields.get('data')?.value;
            if(typeof value==='string'&&value.startsWith('~ask/friend|')){
              const sender=sessions.get(issued),target=fields.get('for'),p=value.split('|');
              if(body.value.length!==2||fields.size!==2||fields.get('data')?.tag!==11||target?.tag!==7||!Number.isInteger(target.value)||p.length!==3||p[1]!==sender.character.name||p[2]!==sender.character.sex){log({event:'friend-rejected',reason:'shape'});continue;}
              const result=friendStore.request(uid,String(target.value));
              if(result.kind==='requested')friendNotice(String(target.value),'FriendRequest',uid);
              if(result.kind==='accepted')friendNotice(result.requester,'FriendAccept',uid);
              log({event:'friend-action',kind:result.kind});continue;
            }
          }
          if(chatRelay&&object.tag===19&&object.value.code===22){
            if(moderation&&moderation.remaining(uid)){muteNotice(uid,moderation.remaining(uid));continue;}
            let request;try{request=readRollRequest(22,object.value.data);}catch{log({event:'command-rejected',reason:'shape-or-mode'});continue;}
            prune();const sender=sessions.get(issued),connected=[...sessions.values()].filter(s=>s.socket&&!s.socket.destroyed);let targets,scope;
            if(request.send===1){if(!sender.room)continue;targets=connected.filter(s=>s.room===sender.room);scope=JSON.stringify(['room',sender.room]);}
            else if(request.send===0){targets=connected;scope='global';}
            else{const target=connected.find(s=>s!==sender&&s.uid===request.recipient);if(!target)continue;targets=[sender,target];scope=JSON.stringify(['private',...[sender.uid,target.uid].sort()]);}
            const prepared=chat.prepare({text:'',reply:request.reply},sender,scope);if(!prepared)continue;
            const fields=new Map(prepared.value),payload=rollPayload(request,sender,fields.get('messageID').value,fields.get('replyMessageID').value);
            for(const target of targets)deliver(target,4,payload);
            log({event:'dice-command',sides:request.sides,channel:request.send,recipients:targets.length});continue;
          }
          if(chatRelay&&object.tag===19&&[9,10,11].includes(object.value.code)){
            if(moderation&&moderation.remaining(uid)){muteNotice(uid,moderation.remaining(uid));log({event:'chat-blocked',reason:'muted'});continue;}
            let message;
            try{message=readChatMessage(object.value.code,object.value.data);}catch{log({event:'chat-rejected',reason:'shape-or-text'});continue;}
            prune();const sender=sessions.get(issued),connected=[...sessions.values()].filter(s=>s.socket&&!s.socket.destroyed);let recipients=0,data,targets=[],incoming;
            const decodedCommand=decodeChatText(message.text),commandText=decodedCommand.text,commandWire=text=>decodedCommand.encrypted?encodeChatText(text):text;
            if(/^\s*\/(?:givegold|gold)(?:\s|$)/i.test(commandText)){
              let response;
              try{
                if(!moderation?.isModerator(sender.token,uid))throw Error('Moderator permission required.');
                if(!goldStore)throw Error('Gold grants are available on the account-enabled VM server.');
                const command=goldCommand(commandText),matches=characters().filter(c=>c.id===command.target||c.name.toLowerCase()===command.target.toLowerCase());
                if(matches.length!==1)throw Error('Choose one existing character by name or numeric ID.');
                const target=matches[0],now=Date.now();for(const [key,until]of goldCooldown)if(until<=now)goldCooldown.delete(key);
                if(goldCooldown.has(uid))throw Error('Wait three seconds between gold grants.');
                const grant=goldStore.grant(sender.token,uid,target.id,command.amount);goldCooldown.set(uid,now+3000);
                response=`Granted ${command.amount} XGold to ${target.name}. Account balance: ${grant.after}.`;
                const targetSession=connected.find(s=>s.uid===target.id&&s!==sender);
                if(targetSession){const notice=chat.prepare({text:commandWire(`Moderator granted you ${command.amount} XGold. Account balance: ${grant.after}. Sign in again to refresh the displayed balance.`),reply:''},sender,JSON.stringify(['private',...[uid,target.id].sort()]));deliver(targetSession,9,notice);}
              }catch(error){response=error.message;log({event:'gold-command-rejected'});}
              // Own-sender chat packets only acknowledge the local message ID;
              // the native alert service is required to display command feedback.
              deliver(sender,4,dictionary({type:string('alert'),msg:string(response)}));continue;
            }
            // Preserve the native action prefix for the receiving client's style.
            if(/^\s*\/me(?:\s|$)/i.test(commandText)){
              const action=commandText.replace(/^\s*\/me\s*/i,'').trim();if(!action)continue;message.text=commandWire('/me '+action);
            }
            if(message.channel==='room'){
              data=chat.prepare(message,sender);targets=connected.filter(s=>s.room===sender.room);incoming=10;
            }else if(message.channel==='global'){
              data=chat.prepare(message,sender,'global');targets=connected;incoming=11;
            }else{
              const target=connected.find(s=>s!==sender&&s.uid===message.recipient);
              if(target){data=chat.prepare(message,sender,JSON.stringify(['private',...[sender.uid,target.uid].sort()]));targets=[sender,target];incoming=9;}
            }
            if(data)for(const other of targets){deliver(other,incoming,data);recipients++;}
            log({event:message.channel==='room'?'room-chat':'chat-relay',...(message.channel==='room'?{}:{channel:message.channel}),recipients});continue;
          }
          if(avatarRelay&&object.tag===19){
            let clothing;
            try{clothing=readClothingMessage(object.value.code,object.value.data);}
            catch{log({event:'clothing-rejected',reason:'shape'});continue;}
            if(clothing){
              prune();const sender=sessions.get(issued);let recipients=0;
              const target=clothing.targetName?[...sessions.values()].find(s=>s.room===sender.room&&s.character.name===clothing.targetName):sender;
              if(sender.room&&target&&(target===sender||(partnerUpRelay&&partnerUp.linked(sender.uid,target.uid)))){
                const data=dictionary({id:string(uid),name:string(sender.character.name),data:string(clothing.text)});
                for(const other of sessions.values())if(other!==sender&&other.room===sender.room){deliver(other,5,data);recipients++;}
              }
              log({event:'clothing-relay',recipients});continue;
            }
          }
          if(poseRelay&&object.tag===19){
            const sender=sessions.get(issued);let message;
            try{message=readPoseMessage(object.value.code,object.value.data,sender.character);}
            catch(error){
              // An invalid application action must not tear down transport.
              // Shape diagnostics contain only an allowlisted command and indexes.
              log({event:'pose-rejected',reason:'shape',...(error.poseShape||{})});continue;
            }
            if(message){
              prune();let recipients=0;
              if(poses.route(message,sender,sessions.values())){
                if(message.kind==='stop')invalidatePose(sender.uid);
                const data=dictionary({id:string(uid),name:string(sender.character.name),data:string(message.text)});
                for(const other of sessions.values())if(other!==sender&&other.room===sender.room&&other.socket&&!other.socket.destroyed&&(!message.recipient||other.uid===message.recipient)){
                  deliver(other,5,data);recipients++;
                  if(message.kind==='animation-sync'){
                    other.poseReady.add(sender.uid);restorePoses(other,other.poseReady);
                  }
                }
              }
              log({event:'pose-relay',kind:message.kind,recipients});continue;
            }
          }
          if(partnerUpRelay&&object.tag===19){
            const sender=sessions.get(issued),message=readPartnerUpMessage(object.value.code,object.value.data,sender.character);
            if(message){
              prune();let recipients=0;
              if(partnerUp.route(message,sender,sessions.values())){
                if(['remove','break'].includes(message.kind)){poses.remove(sender.uid);invalidatePose(sender.uid);}
                const data=dictionary({id:string(uid),name:string(sender.character.name),data:string(message.text)});
                for(const other of sessions.values())if(other!==sender&&other.room===sender.room&&other.socket&&!other.socket.destroyed&&(!message.recipient||other.uid===message.recipient)){
                  deliver(other,5,data);recipients++;
                }
              }
              log({event:'partner-up-relay',kind:message.kind,recipients});continue;
            }
          }
          if(pairedDanceRelay&&object.tag===19){
            const sender=sessions.get(issued),message=readPairedDanceMessage(object.value.code,object.value.data,sender.character);
            if(message){
              prune();let recipients=0;
              if(pairedDances.route(message,sender,sessions.values())){
                const data=dictionary({id:string(uid),name:string(sender.character.name),data:string(message.text)});
                for(const other of sessions.values())if(other!==sender&&other.room===sender.room&&other.socket&&!other.socket.destroyed&&(!message.recipient||other.uid===message.recipient)){
                  deliver(other,5,data);recipients++;
                }
              }
              log({event:'paired-dance-relay',kind:message.kind,recipients});continue;
            }
          }
          if((movementRelay||animationRelay)&&object.tag===19){
            const message=readMovementMessage(object.value.code,object.value.data) || (animationRelay&&readAnimationMessage(object.value.code,object.value.data,sessions.get(issued).character));
            if(message){
              const sender=sessions.get(issued);let recipients=0;
              if(sender.room){
                prune();
                const data=dictionary({id:string(uid),name:string(sender.character.name),data:string(message.text)});
                for(const other of sessions.values())if(other!==sender&&other.room===sender.room&&other.socket&&!other.socket.destroyed){
                  deliver(other,5,data);recipients++;
                }
              }
              // Movement is transient: do not replay obsolete paths after reconnect.
              log({event:['walk','mode'].includes(message.kind)?'movement-relay':'animation-relay',kind:message.kind,recipients});continue;
            }
          }
          if(avatarRelay&&object.tag===19&&[7,8].includes(object.value.code)){
            const sender=sessions.get(issued);
            const message=readSetupMessage(object.value.code,object.value.data,sender.character);
            if(message&&sender.room){
              prune();
              const data=dictionary({id:string(uid),name:string(sender.character.name),data:string(message.text)});
              let recipients=0;
              for(const other of sessions.values())if(other!==sender&&other.room===sender.room&&(!message.recipient||other.uid===message.recipient)){
                // Both targeted and room action commands use the legacy action
                // inbox. Event 9 is a newer chat-display path, not that inbox.
                deliver(other,5,data);recipients++;
                if(poseRelay&&message.kind==='animation-state'){
                  other.poseReady.add(sender.uid);restorePoses(other,other.poseReady);
                }
              }
              log({event:'avatar-relay',code:5,recipients,...(message.kind?{kind:message.kind}:{})});
            }
            if(poseRelay&&!message){
              const shape=ignoredActionShape(object.value.code,object.value.data);
              if(shape)log({event:'action-ignored',code:object.value.code,...shape});
            }
            continue;
          }
          if(object.tag===19&&[14,17,39].includes(object.value.code)){
            if(![0,1].includes(object.value.data.tag))throw new Error('Invalid control body');
            if(object.value.code===39){
              for(const [key,session] of sessions)if(session.uid===uid){leave(session);sessions.delete(key);}
              log({event:'logout'});closed=true;socket.end();return;
            }
            if(object.value.code===14){
              leave(sessions.get(issued));
              event(4,{tag:11,value:'JoinedLobby'});log({event:'room-left'});
            }else{
              event(4,{tag:201,value:[['type',{tag:11,value:'SharedLocationsList'}],['data',{tag:202,value:sharedLocations()}]]});
            }
          }
        }
      } catch(error) {
        // Only categories derived from our own errors; never echo input values.
        const message=String(error?.message??'');
        const reason=message==='Unexpected transport'?'transport':message==='Expected event'?'object-kind':message==='Invalid keepalive'?'keepalive':message.startsWith('Unsupported object tag')?'object-tag':'malformed-or-unsupported';
        fail(reason);
      }
    });
    socket.on('timeout',()=>{log({event:'idle-timeout'});socket.destroy();});
    socket.on('error',()=>log({event:'socket-error'}));
    socket.on('close',()=>{
      clearTimeout(authTimer);clearTimeout(disconnectTimer);sockets.delete(socket);
      if(issued && sessions.has(issued)) {const session=sessions.get(issued);session.socket=null;session.expires=Date.now()+resumeMs;}
      log({event:'closed',approved});
    });
  });
  return {
    server,
    friendNotice,
    muteNotice,
    profileUpdated(uid){
      const character=characterFor(uid);if(!character)return false;
      const data=dictionary({id:string(uid),name:string(character.name),data:string('~action/update_profile|')});let recipients=0;
      for(const session of sessions.values()){deliver(session,5,data);recipients++;}
      log({event:'profile-cache-invalidated',recipients});return true;
    },
    isConnected(uid){prune();return [...sessions.values()].some(s=>s.uid===uid&&s.socket&&!s.socket.destroyed);},
    joinRoom(uid,room){
      if(typeof room!=='string'||!room||room.length>128||/[\x00-\x1f\x7f]/.test(room))return false;
      const session=[...sessions.values()].find(session=>session.uid===uid&&session.socket&&!session.socket.destroyed);
      if(!session)return false;
      prune();
      const changed=session.room!==room;
      if(changed)leave(session);
      session.sendEvent(4,{tag:201,value:[['type',{tag:11,value:'JoinedRoom'}],['room',{tag:11,value:room}],['users',{tag:202,value:presence?roster(room,session):[]}]]});
      session.room=room;if(changed)announce(session,'JoinRoom');log({event:'room-joined'});return true;
    },
    roomFor(uid){prune();return [...sessions.values()].find(session=>session.uid===uid)?.room??null;},
    async close() {
      if(expiryTimer)clearInterval(expiryTimer);
      for(const socket of sockets)socket.destroy();
      sessions.clear();
      if(server.listening)await new Promise(resolve=>server.close(resolve));
    }
  };
}
module.exports={createGameTcp,readAuth};
