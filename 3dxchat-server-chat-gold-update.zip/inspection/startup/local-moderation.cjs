const crypto=require('node:crypto');
function createModeration({profile,characters,moderatorId,accounts=null}={}){
 if(!profile||typeof characters!=='function'||!characters().some(c=>c.id===moderatorId))throw Error('Explicit local moderator character required');
 const moderatorToken='offline.moderator.'+crypto.randomBytes(16).toString('hex'),muted=new Map();
 const validToken=token=>accounts?accounts.validToken(token):token===profile.token||token===moderatorToken;
 const mayAct=(token,uid)=>accounts?accounts.mayAct(token,uid):characters().some(c=>c.id===uid)&&(token===moderatorToken?uid===moderatorId:token===profile.token&&uid!==moderatorId);
 const isModerator=(token,uid)=>accounts?accounts.isModerator(token,uid):token===moderatorToken&&uid===moderatorId;
 return {validToken,mayAct,isModerator,isModeratorToken:token=>accounts?accounts.isModeratorToken(token):token===moderatorToken,
  canCreate:token=>accounts?accounts.canCreate(token):false,
  createCharacter:(token,name,sex)=>accounts?accounts.createCharacter(token,name,sex):{error:'unauthorized'},
  login(path){if(accounts)return accounts.login(path);const moderator=path==='/login3';return {...profile,token:moderator?moderatorToken:profile.token,moderator,characters:characters().filter(c=>moderator?c.id===moderatorId:c.id!==moderatorId)};},
  mute(token,actor,target,mode,preset){
   if(!isModerator(token,actor))return {status:403};
   // MuteWindow sends a preset index, not seconds. Its fixed labels establish
   // 1=10 min, 2=30 min, 3=2 h, 4=6 h, 5=24 h; -1 is native unmute.
   const durations={'-1':0,'1':600,'2':1800,'3':7200,'4':21600,'5':86400};
   if(!characters().some(c=>c.id===target)||target===actor||mode!=='1'||!Object.hasOwn(durations,preset))return {status:400};
   const time=durations[preset];if(time)muted.set(target,Date.now()+time*1000);else muted.delete(target);
   return {status:200,target,time,mode:1};
  },
  remaining(uid){return Math.max(0,Math.ceil(((muted.get(uid)||0)-Date.now())/1000));},
  expired(){const ids=[];for(const [uid,until] of muted)if(until<=Date.now()){muted.delete(uid);ids.push(uid);}return ids;}
 };
}
module.exports={createModeration};
