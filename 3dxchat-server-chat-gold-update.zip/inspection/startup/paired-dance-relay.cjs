function readPairedDanceMessage(code,body,character){
  let value,recipient=null;
  if(code===7){
    if(body?.tag!==201||!Array.isArray(body.value))return null;
    const fields=new Map(body.value),data=fields.get('data');
    if(data?.tag!==11||!/^~(?:action\/(?:coupleDance|acceptDance)|ask\/coupleDance)\|/.test(data.value))return null;
    const target=fields.get('for');
    if(body.value.length!==2||fields.size!==2||target?.tag!==7||!Number.isInteger(target.value)||target.value<1||target.value>2147483647)throw Error('Invalid paired recipient');
    recipient=String(target.value);value=data.value;
  }else if(code===8&&body?.tag===11&&typeof body.value==='string')value=body.value;
  else return null;
  const p=value.split('|'),command=p[0];
  if(code===7&&command==='~ask/coupleDance'){
    if(p.length!==2||p[1]!==character.sex)throw Error('Invalid dance request sex');
    return {kind:'request',recipient,text:value};
  }
  if(code===7&&command==='~action/coupleDance'){
    if(p.length!==3||p[1]!==character.name||p[2]!==character.sex)throw Error('Invalid dance request identity');
    return {kind:'request',recipient,text:'~ask/coupleDance|'+character.sex};
  }
  if(code===7&&command==='~action/acceptDance'){
    if(p.length!==3||p[1]!==character.name||p[2]!=='')throw Error('Invalid dance accept identity');
    return {kind:'accept',recipient,text:value};
  }
  if(code!==8)return null;
  if(command==='~action/SetAnimation'){
    if(p.length!==4||p[3]!==''||!p[1]||p[1].length>128||!p[2]||p[2].length>256||/[\x00-\x1f\x7f]/.test(p[1]+p[2]))throw Error('Invalid paired animation change');
    // The initiator emits separate changes for itself and its accepted partner.
    return {kind:'change',recipient:null,subjectName:p[1],text:value};
  }
  const kinds={'~action/ApplyCoupleDance':'start','~action/ApplyStopCoupleDance':'stop','~action/breakDance':'break'};
  if(!Object.hasOwn(kinds,command))return null;
  const kind=kinds[command];
  if(p[1]!==character.name||p.at(-1)!==''||p.length!==(kind==='break'?3:4))throw Error('Invalid paired dance identity');
  if(kind!=='break'&&(!p[2]||p[2].length>128||/[\x00-\x1f\x7f]/.test(p[2])))throw Error('Invalid paired partner');
  return {kind,recipient:null,partnerName:kind==='break'?null:p[2],text:value};
}
function createPairedDanceState(){
  const requests=new Map(),partners=new Map();
  function remove(uid){
    const partner=partners.get(uid);partners.delete(uid);if(partner)partners.delete(partner);
    for(const [key,r] of requests)if(r.from===uid||r.to===uid)requests.delete(key);
  }
  return {remove,
    route(message,sender,sessions){
      const now=Date.now();for(const [key,r] of requests)if(r.until<=now)requests.delete(key);
      if(!sender.room)return false;
      const connected=[...sessions].filter(s=>s!==sender&&s.room===sender.room&&s.socket&&!s.socket.destroyed);
      const target=message.recipient?connected.find(s=>s.uid===message.recipient):connected.find(s=>s.uid===partners.get(sender.uid));
      if(!target)return false;
      if(message.kind==='request'){
        if(partners.has(sender.uid)||partners.has(target.uid))return false;
        requests.set(sender.uid,{from:sender.uid,to:target.uid,room:sender.room,until:now+60000});return true;
      }
      if(message.kind==='accept'){
        const r=requests.get(target.uid);
        if(!r||r.to!==sender.uid||r.room!==sender.room||partners.has(sender.uid)||partners.has(target.uid))return false;
        requests.delete(target.uid);partners.set(sender.uid,target.uid);partners.set(target.uid,sender.uid);return true;
      }
      if(message.partnerName&&message.partnerName!==target.character.name)return false;
      if(message.kind==='change')return message.subjectName===sender.character.name||message.subjectName===target.character.name;
      if(message.kind!=='start')remove(sender.uid);
      return true;
    }
  };
}
module.exports={readPairedDanceMessage,createPairedDanceState};
