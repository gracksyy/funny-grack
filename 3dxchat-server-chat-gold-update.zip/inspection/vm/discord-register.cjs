const fs=require('node:fs');const {validateBotConfig}=require('./discord-service.cjs');
const commands=[
 {name:'register',description:'Create your linked game account',options:[{type:3,name:'email',description:'Game login email (not verified by email delivery)',required:true,max_length:254}]},
 {name:'reset-password',description:'Get a private link to reset your game password'},
 {name:'account',description:'View your game account and characters'},
 {name:'staff-reset',description:'Staff: issue a password reset for a linked Discord user',default_member_permissions:'0',options:[{type:6,name:'user',description:'Account owner',required:true}]}
].map(c=>({...c,type:1}));
module.exports={commands};
if(require.main===module)(async()=>{
 const c=validateBotConfig(JSON.parse(fs.readFileSync(process.argv[2]||'/app/discord-config.json','utf8'))),token=fs.readFileSync(process.argv[3]||'/run/secrets/discord_token','utf8').trim();
 for(const command of commands){const r=await fetch(`https://discord.com/api/v10/applications/${c.applicationId}/guilds/${c.guildId}/commands`,{method:'POST',headers:{authorization:'Bot '+token,'content-type':'application/json'},body:JSON.stringify(command),signal:AbortSignal.timeout(15000)});if(!r.ok)throw Error('Registration failed');}
 console.log('Four guild account commands registered.');
})().catch(()=>{console.error('Command registration failed. Check application/guild IDs, bot token and invitation.');process.exitCode=1;});
