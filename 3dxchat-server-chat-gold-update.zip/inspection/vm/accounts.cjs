const fs=require('node:fs'),path=require('node:path'),readline=require('node:readline');
const {validateConfig}=require('./server.cjs');
async function secret(prompt){
 if(!process.stdin.isTTY)throw Error('Use an interactive terminal or --password-stdin');
 process.stdout.write(prompt);readline.emitKeypressEvents(process.stdin);process.stdin.setRawMode(true);process.stdin.resume();
 return new Promise((resolve,reject)=>{let value='';function done(error){process.stdin.removeListener('keypress',onKey);process.stdin.setRawMode(false);process.stdin.pause();process.stdout.write('\n');if(error)reject(error);else resolve(value);}
  function onKey(text,key={}){if(key.ctrl&&key.name==='c')return done(Error('Cancelled'));if(key.name==='return'||key.name==='enter')return done();if(key.name==='backspace'){if(value){value=Array.from(value).slice(0,-1).join('');process.stdout.write('\b \b');}return;}if(text&&!key.ctrl&&!key.meta&&!key.sequence?.startsWith('\x1b')&&!/[\x00-\x1f\x7f]/.test(text)&&value.length+text.length<=128){value+=text;process.stdout.write('*');}}
  process.stdin.on('keypress',onKey);
 });
}
async function main(){
 const argv=process.argv.slice(2),action=argv.shift();if(!['list','create','set-password'].includes(action))throw Error('Use list, create --email EMAIL [--role user|moderator], or set-password --email EMAIL');
 const args={};for(let i=0;i<argv.length;i++){const key=argv[i];if(key==='--password-stdin'){args.stdin=true;continue;}if(!['--email','--role','--config'].includes(key)||args[key]!==undefined||!argv[i+1])throw Error('Invalid arguments; passwords are prompted, not command-line arguments');args[key]=argv[++i];}
 const configFile=args['--config']?path.resolve(args['--config']):path.resolve(__dirname,'../../server-config.json');
 const config=validateConfig(JSON.parse(fs.readFileSync(configFile,'utf8'))),root=path.dirname(configFile);
 const key=fs.readFileSync(path.join(root,config.dataDirectory,'account-admin.key'),'utf8').trim();
 const headers={'x-vm-admin-key':key};let body;
 if(action!=='list'){
  if(!args['--email'])throw Error('Email required');let password;
  if(args.stdin){let bytes=0,parts=[];for await(const chunk of process.stdin){bytes+=chunk.length;if(bytes>4096)throw Error('Password input too large');parts.push(chunk);}password=Buffer.concat(parts).toString('utf8').replace(/\r?\n$/,'');}
  else{password=await secret('Password: ');if(password!==await secret('Confirm password: '))throw Error('Passwords differ');}
  body={email:args['--email'],password,...(action==='create'?{role:args['--role']||'user'}:{})};headers['content-type']='application/json';
 }
 const route=action==='set-password'?'/admin/accounts/password':'/admin/accounts';
 const response=await fetch('http://127.0.0.1:'+config.httpPort+route,{method:action==='list'?'GET':'POST',headers,...(body?{body:JSON.stringify(body)}:{})});
 if(body)body.password='';if(!response.ok)throw Error('Account operation rejected (HTTP '+response.status+'). Check email, password rules, duplicate account and capacity.');
 console.log(JSON.stringify(await response.json(),null,2));
}
module.exports={main};if(require.main===module)main().catch(error=>{console.error(error.message);process.exitCode=1;});
