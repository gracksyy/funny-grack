const fs=require('node:fs'),crypto=require('node:crypto'),http=require('node:http');
const snowflake=v=>typeof v==='string'&&/^[0-9]{17,20}$/.test(v);
function validateBotConfig(c){
 if(!c||!snowflake(c.applicationId)||!snowflake(c.guildId)||! /^[a-f0-9]{64}$/i.test(c.publicKey)||!Array.isArray(c.staffUserIds)||c.staffUserIds.some(v=>!snowflake(v)))throw Error('Invalid Discord configuration');
 const url=new URL(c.publicUrl);if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash)throw Error('Public URL must be an HTTPS origin');
 if(!Number.isInteger(c.port)||c.port<1024||c.port>65535)throw Error('Invalid bot port');return c;
}
function managementClient({keyFile,base='http://127.0.0.1:8080'}){
 const url=new URL(base);if(url.protocol!=='http:'||url.hostname!=='127.0.0.1'||url.pathname!=='/')throw Error('Management API must be loopback');
 return async(route,value)=>{
  const key=fs.readFileSync(keyFile,'utf8').trim();if(!/^[a-f0-9]{64}$/.test(key))throw Error('Management key unavailable');
  const r=await fetch(new URL(route,url),{method:value?'POST':'GET',headers:{'x-vm-admin-key':key,...(value?{'content-type':'application/json'}:{})},body:value?JSON.stringify(value):undefined,signal:AbortSignal.timeout(1800)});
  if(!r.ok)throw Error('Account operation rejected');return r.json();
 };
}
function createDiscordService({config,manage,now=Date.now,log=()=>{},deliver=async(d,data)=>{
 const r=await fetch(`https://discord.com/api/v10/webhooks/${d.application_id}/${d.token}/messages/@original`,{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify(data),signal:AbortSignal.timeout(5000)});if(!r.ok)throw Error('Discord reply failed');
}}){
 validateBotConfig(config);const origin=new URL(config.publicUrl).origin;
 const publicKey=crypto.createPublicKey({key:Buffer.concat([Buffer.from('302a300506032b6570032100','hex'),Buffer.from(config.publicKey,'hex')]),format:'der',type:'spki'});
 const tickets=new Map(),seen=new Map(),cooldowns=new Map();let active=0;
 const sweep=()=>{const t=now();for(const map of [tickets,seen,cooldowns])for(const [k,v]of map)if((typeof v==='number'?v:v.until)<=t)map.delete(k);};
 const reply=content=>({type:4,data:{content,flags:64,allowed_mentions:{parse:[]}}});
 async function command(d){
  if(d.guild_id!==config.guildId||d.application_id!==config.applicationId||!snowflake(d.member?.user?.id))return reply('This command is available only in the configured server.');
  const actor=d.member.user.id,name=d.data?.name,opts=d.data?.options||[];
  if(!['register','reset-password','account','staff-reset'].includes(name))return reply('Unknown account command.');
  if(cooldowns.has(actor))return reply('Please wait 10 seconds before another account command.');
  if(cooldowns.size>=2048)return reply('Account service is busy.');cooldowns.set(actor,now()+10000);
  let target=actor;
  if(name==='staff-reset'){
   if(!config.staffUserIds.includes(actor))return reply('You are not authorized to reset another account.');
   target=opts.find(o=>o.name==='user')?.value;if(!snowflake(target))return reply('Select a Discord user.');
  }
  let accounts=(await manage('/admin/accounts')).accounts,account=accounts.find(a=>a.discordId===target);
  if(name==='account')return reply(account?`Account: ${account.email}\nCharacters: ${account.characters.map(c=>c.name).join(', ')||'none'}\nPassword configured: ${account.passwordSet?'yes':'no'}`:'No linked account. Use /register first.');
  if(name==='register'){
   const email=opts.find(o=>o.name==='email')?.value;
   if(account)return reply('You already have a linked account. Use /reset-password.');
   account=(await manage('/admin/accounts/discord',{email,discordId:actor})).account;
  }
  if(!account)return reply('No linked account. Registration cannot claim an existing unlinked account.');
  if(tickets.size>=256)return reply('Password service is busy. Try again later.');
  // One valid ticket per account. A new request invalidates previous links.
  for(const [k,v]of tickets)if(v.accountId===account.id)tickets.delete(k);
  const token=crypto.randomBytes(32).toString('hex');tickets.set(crypto.createHash('sha256').update(token).digest('hex'),{accountId:account.id,email:account.email,discordId:target,until:now()+600000});
  log({event:'password-link-issued',actorId:actor,targetId:target,operation:name});
  return reply(`${name==='staff-reset'?'Give this link privately to the selected user. ':''}Set your game password within 10 minutes: ${origin}/setup#${token}\nThis link grants password-reset access. Keep it private.`);
 }
 const script=`'use strict';const token=location.hash.slice(1);history.replaceState(null,'','/setup');document.querySelector('form').addEventListener('submit',async e=>{e.preventDefault();const p=document.querySelector('#password'),c=document.querySelector('#confirm'),s=document.querySelector('#status');if(p.value!==c.value){s.textContent='Passwords do not match.';return;}try{const r=await fetch('/redeem',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({token,password:p.value})});p.value='';c.value='';s.textContent=r.ok?'Password saved. You can sign in to the game now.':'Link expired, already used, or password invalid. Request a new link in Discord.';if(r.ok)document.querySelector('button').disabled=true;}catch{s.textContent='Connection failed. Request a new link if necessary.';}});`;
 const page='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Game account password</title><body><h1>Set your game password</h1><p>Use a unique test password: 8–128 characters, without spaces or control characters.</p><form><label>New password <input id="password" type="password" minlength="8" maxlength="128" autocomplete="new-password" required></label><br><label>Confirm password <input id="confirm" type="password" minlength="8" maxlength="128" autocomplete="new-password" required></label><br><button>Save password</button></form><p id="status" role="status"></p><script src="/setup.js"></script></body></html>';
 const server=http.createServer(async(req,res)=>{
  const send=(status,body,type='application/json')=>{if(res.writableEnded)return;res.writeHead(status,{'content-type':type,'cache-control':'no-store','referrer-policy':'no-referrer','x-content-type-options':'nosniff','content-security-policy':"default-src 'none'; script-src 'self'; connect-src 'self'; form-action 'none'; base-uri 'none'; frame-ancestors 'none'"});res.end(body);};
  const route=req.url?.split('?')[0];sweep();
  if(req.method==='GET'&&route==='/health'){send(200,'{"ok":true}');return;}
  if(req.method==='GET'&&route==='/setup'){send(200,page,'text/html; charset=utf-8');return;}
  if(req.method==='GET'&&route==='/setup.js'){send(200,script,'application/javascript');return;}
  if(req.method!=='POST'||!['/interactions','/redeem'].includes(route)){req.resume();send(404,'{}');return;}
  if(active>=4){req.resume();send(429,'{}');return;}active++;
  try{
   let size=0;const chunks=[];for await(const b of req){size+=b.length;if(size>16384){send(413,'{}');return;}chunks.push(b);}const raw=Buffer.concat(chunks);
   if(route==='/interactions'){
    const signature=req.headers['x-signature-ed25519'],stamp=req.headers['x-signature-timestamp'];
    if(typeof signature!=='string'||!/^[a-f0-9]{128}$/i.test(signature)||typeof stamp!=='string'||!/^\d{10}$/.test(stamp)||Math.abs(now()-Number(stamp)*1000)>300000||!crypto.verify(null,Buffer.concat([Buffer.from(stamp),raw]),publicKey,Buffer.from(signature,'hex'))){send(401,'{}');return;}
    const d=JSON.parse(raw);if(d.type===1){send(200,'{"type":1}');return;}
    if(d.type!==2||!snowflake(d.id)||seen.has(d.id)||seen.size>=2048){send(400,'{}');return;}seen.set(d.id,now()+300000);
    if(d.application_id!==config.applicationId||typeof d.token!=='string'||! /^[A-Za-z0-9._-]{1,256}$/.test(d.token)){send(400,'{}');return;}
    send(200,'{"type":5,"data":{"flags":64}}');
    let result;try{result=await command(d);}catch{result=reply('Account operation failed. The email may already be in use or account capacity reached. Try again later.');}
    try{await deliver(d,result.data);}catch{log({event:'discord-reply-failed'});}
   }else{
    if(req.headers.origin!==origin||req.headers['content-type']?.split(';')[0]!=='application/json'){send(403,'{}');return;}
    const value=JSON.parse(raw);if(typeof value.token!=='string'||!/^[a-f0-9]{64}$/.test(value.token)||typeof value.password!=='string'||value.password.length<8||value.password.length>128||/\s|[\x00-\x1f\x7f]/.test(value.password)){send(400,'{}');return;}
    const hash=crypto.createHash('sha256').update(value.token).digest('hex'),ticket=tickets.get(hash);if(!ticket){send(400,'{}');return;}
    tickets.delete(hash); // Consume before awaiting: simultaneous submissions cannot reuse a link.
    const account=(await manage('/admin/accounts')).accounts.find(a=>a.id===ticket.accountId&&a.email===ticket.email&&a.discordId===ticket.discordId);
    if(!account){send(400,'{}');return;}
    await manage('/admin/accounts/password',{email:account.email,password:value.password});value.password='';log({event:'password-updated',targetId:ticket.discordId});send(200,'{"ok":true}');
   }
  }catch{send(400,'{}');}finally{active--;}
 });
 server.requestTimeout=10000;server.headersTimeout=10000;
 return {server};
}
module.exports={validateBotConfig,managementClient,createDiscordService};
if(require.main===module){try{
 const config=JSON.parse(fs.readFileSync(process.env.DISCORD_CONFIG_FILE||'/app/discord-config.json','utf8'));
 const log=x=>console.log(JSON.stringify({at:new Date().toISOString(),...x}));
 const {server}=createDiscordService({config,manage:managementClient({keyFile:'/run/secrets/vm_admin_key'}),log});
 server.listen(config.port,'0.0.0.0',()=>log({event:'discord-account-service-ready'}));for(const s of ['SIGINT','SIGTERM'])process.on(s,()=>server.close());
}catch{console.error('{"event":"discord-startup-failed","reason":"check-configuration"}');process.exitCode=1;}}
